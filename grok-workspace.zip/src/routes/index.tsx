import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { TrueFrameApp } from "@/components/trueframe/app";
import { secondOpinion } from "@/lib/second-opinion";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const ask = useServerFn(secondOpinion);
  return (
    <TrueFrameApp
      onSecondOpinion={(images, kind, localScore) => ask({ data: { images, kind, localScore } })}
    />
  );
}
