import { useEffect, useRef, useState } from "react";
import {
  Aperture,
  Clapperboard,
  Download,
  History,
  ImageIcon,
  TriangleAlert,
  Upload,
} from "lucide-react";
import { analyzeFile, opinionJpegs } from "@/lib/forensics/analyze";
import type { Report, Verdict } from "@/lib/forensics/types";
import type { Opinion } from "@/lib/opinion";

const HISTORY_KEY = "trueframe.history.v1";

type HistoryItem = {
  id: string;
  fileName: string;
  kind: "image" | "video";
  verdict: Verdict;
  score: number;
  at: number;
};

type OpinionState =
  | { state: "idle" }
  | { state: "loading" }
  | { state: "done"; result: Opinion };

const COPY: Record<Verdict, { title: string; lede: string }> = {
  likely_ai: {
    title: "Looks generated",
    lede: "A generator tag, a trained-model credential, or a generation log is in this file.",
  },
  likely_real: {
    title: "Looks photographed",
    lede: "A known camera left its make and model, and nothing here names a generator.",
  },
  inconclusive: {
    title: "Not enough to call",
    lede: "No decisive camera tag or generator tag. Treat the origin as unknown.",
  },
};

export function TrueFrameApp({
  mode = "web",
  onSecondOpinion,
}: {
  mode?: "web" | "apk";
  onSecondOpinion?: (images: string[], kind: "image" | "video", localScore: number) => Promise<Opinion>;
}) {
  const [drag, setDrag] = useState(false);
  const [phase, setPhase] = useState<"idle" | "working" | "done" | "error">("idle");
  const [status, setStatus] = useState("Ready");
  const [ratio, setRatio] = useState(0);
  const [error, setError] = useState("");
  const [report, setReport] = useState<Report | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [opinion, setOpinion] = useState<OpinionState>({ state: "idle" });
  const fileRef = useRef<File | null>(null);
  const previewRef = useRef<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(HISTORY_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as HistoryItem[];
      if (Array.isArray(parsed)) setHistory(parsed.slice(0, 8));
    } catch {
      /* ignore broken local history */
    }
  }, []);

  useEffect(() => {
    return () => {
      if (previewRef.current) URL.revokeObjectURL(previewRef.current);
    };
  }, []);

  async function run(file: File) {
    setPhase("working");
    setError("");
    setOpinion({ state: "idle" });
    setStatus("Reading the file");
    setRatio(0.08);
    fileRef.current = file;
    try {
      const next = await analyzeFile(file, (label, value) => {
        setStatus(label);
        setRatio(value);
      });
      if (previewRef.current && previewRef.current !== next.previewUrl) URL.revokeObjectURL(previewRef.current);
      previewRef.current = next.previewUrl;
      setReport(next);
      setPhase("done");
      setRatio(1);
      setStatus("Done");
      const item: HistoryItem = {
        id: next.id,
        fileName: next.fileName,
        kind: next.kind,
        verdict: next.verdict,
        score: next.score,
        at: Date.now(),
      };
      setHistory((prev) => {
        const items = [item, ...prev].slice(0, 8);
        try {
          localStorage.setItem(HISTORY_KEY, JSON.stringify(items));
        } catch {
          /* private mode */
        }
        return items;
      });
    } catch (err) {
      setPhase("error");
      setStatus("Could not screen that file");
      setError(err instanceof Error ? err.message : "Something went wrong reading that file.");
    }
  }

  async function ask() {
    if (!onSecondOpinion || !report || !fileRef.current) return;
    setOpinion({ state: "loading" });
    try {
      const images = await opinionJpegs(fileRef.current);
      if (!images.length) throw new Error("Could not make a preview to send.");
      const result = await onSecondOpinion(images, report.kind, report.score);
      setOpinion({ state: "done", result });
    } catch (err) {
      setOpinion({
        state: "done",
        result: { ok: false, error: err instanceof Error ? err.message : "The second look failed." },
      });
    }
  }

  return (
    <div className="min-h-screen bg-paper text-ink">
      <div className="mx-auto flex min-h-screen w-full max-w-3xl flex-col px-5 py-8 md:py-12">
        <header className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-ink text-paper" aria-hidden="true">
              <Aperture className="h-6 w-6" strokeWidth={1.75} />
            </span>
            <div>
              <p className="font-display text-3xl leading-none font-semibold tracking-tight text-balance">TrueFrame</p>
              <p className="mt-1 text-sm text-muted">Photo and video origin check</p>
            </div>
          </div>
          <p className="pt-1 text-right text-xs leading-snug text-muted">
            Developed by
            <span className="mt-1 block font-display text-base leading-none font-semibold text-ink">NETHA MANOJ</span>
          </p>
        </header>

        <p className="mt-6 max-w-2xl text-sm text-pretty text-muted">
          Drop a still or a clip. TrueFrame reads generator tags, camera metadata, and content credentials on this device.
          Texture is only a hint. This is a screen, not proof.
        </p>

        <label
          className={
            "mt-6 flex cursor-pointer flex-col items-center justify-center rounded-3xl border border-dashed px-6 py-10 text-center transition-colors " +
            (drag ? "border-brass bg-mid-soft" : "border-line bg-card") +
            (phase === "working" ? " pointer-events-none opacity-80" : "")
          }
          onDragOver={(e) => {
            e.preventDefault();
            setDrag(true);
          }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDrag(false);
            const file = e.dataTransfer.files?.[0];
            if (file) void run(file);
          }}
        >
          <input
            ref={inputRef}
            type="file"
            accept="image/*,video/*,.jpg,.jpeg,.png,.webp,.gif,.mp4,.webm,.mov,.m4v"
            className="sr-only"
            onChange={(e) => {
              const file = e.target.files?.[0];
              e.target.value = "";
              if (file) void run(file);
            }}
          />
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-paper-deep text-brass">
            <Upload className="h-5 w-5" strokeWidth={1.75} />
          </span>
          <span className="mt-4 font-display text-2xl font-semibold text-balance">
            {phase === "working" ? status : "Drop a photo or video"}
          </span>
          <span className="mt-2 max-w-sm text-sm text-pretty text-muted">
            JPG, PNG, WEBP, GIF, MP4, WEBM, or MOV. Nothing is uploaded for the on-device screen.
          </span>
          {phase === "working" ? (
            <span className="mt-5 h-1.5 w-full max-w-xs overflow-hidden rounded-full bg-paper-deep">
              <span className="block h-full bg-brass transition-all" style={{ width: `${Math.round(ratio * 100)}%` }} />
            </span>
          ) : (
            <span className="mt-5 inline-flex min-h-11 items-center rounded-full bg-brass px-5 text-sm font-medium text-paper">
              Choose a file
            </span>
          )}
        </label>

        {phase === "error" ? (
          <p className="mt-4 flex items-start gap-2 text-sm text-ai" role="alert">
            <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" />
            {error}
          </p>
        ) : null}

        <div aria-live="polite">
          {report && phase === "done" ? (
            <ReportView
              report={report}
              opinion={opinion}
              canAsk={Boolean(onSecondOpinion)}
              onAsk={() => void ask()}
            />
          ) : null}
        </div>

        {mode === "web" ? (
          <section className="mt-6 rounded-3xl bg-ink px-5 py-5 text-paper md:px-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-xs tracking-wide text-paper-deep uppercase">Android app</p>
                <h2 className="mt-1 font-display text-2xl font-semibold text-balance">Install TrueFrame</h2>
                <p className="mt-2 max-w-md text-sm text-pretty text-paper-deep">
                  Download the APK and open it on your phone. Allow install from this source if Android asks. The app
                  screens files on the phone and does not upload them.
                </p>
              </div>
              <a
                href="/trueframe.apk"
                download="TrueFrame.apk"
                className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-paper px-5 text-sm font-medium text-ink"
              >
                <Download className="h-4 w-4" />
                Download APK
              </a>
            </div>
            <p className="mt-4 text-xs text-paper-deep">Developed by NETHA MANOJ</p>
          </section>
        ) : (
          <p className="mt-6 text-sm text-muted">On-phone screen. Files stay on this device. Developed by NETHA MANOJ.</p>
        )}

        {phase === "idle" ? (
          <ol className="mt-6 grid gap-3 sm:grid-cols-3">
            <Hint n="01" title="Add a file" body="A camera original, a download, or a clip from your camera roll." />
            <Hint n="02" title="Read the file" body="Maker tags, C2PA credentials, and generator logs count more than looks." />
            <Hint n="03" title="See the call" body="Photographed, generated, or not enough to say. Every point is listed." />
          </ol>
        ) : null}

        {history.length > 0 ? (
          <section className="mt-8">
            <h2 className="flex items-center gap-2 text-sm font-medium text-muted">
              <History className="h-4 w-4" />
              Recent screens
            </h2>
            <ul className="mt-3 divide-y divide-line rounded-2xl border border-line bg-card">
              {history.map((item) => (
                <li key={item.id} className="flex items-center justify-between gap-3 px-4 py-3">
                  <span className="min-w-0">
                    <span className="block truncate text-sm">{item.fileName}</span>
                    <span className="text-xs text-muted">{item.kind === "video" ? "Video" : "Image"}</span>
                  </span>
                  <span className={`shrink-0 rounded-full px-3 py-1 text-xs font-medium ${tone(item.verdict)}`}>
                    {COPY[item.verdict].title} · {item.score}
                  </span>
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        <footer className="mt-auto border-t border-line pt-6">
          <p className="font-display text-xl font-semibold">Developed by NETHA MANOJ</p>
          <p className="mt-2 max-w-xl text-sm text-pretty text-muted">
            A clean result can still be wrong. Generators strip tags, editors can forge a camera name, and a real photo
            can be partly filled by a model. Use this to decide what to inspect next.
          </p>
        </footer>
      </div>
    </div>
  );
}

function Hint({ n, title, body }: { n: string; title: string; body: string }) {
  return (
    <li className="rounded-2xl border border-line bg-card px-4 py-4">
      <p className="font-display text-sm text-brass">{n}</p>
      <p className="mt-2 font-medium">{title}</p>
      <p className="mt-1 text-sm text-pretty text-muted">{body}</p>
    </li>
  );
}

function ReportView({
  report,
  opinion,
  canAsk,
  onAsk,
}: {
  report: Report;
  opinion: OpinionState;
  canAsk: boolean;
  onAsk: () => void;
}) {
  const copy = COPY[report.verdict];
  return (
    <article className="mt-8 overflow-hidden rounded-3xl border border-line bg-card">
      <div className="grid gap-0 md:grid-cols-2">
        <div className="bg-paper-deep p-4">
          {report.kind === "video" ? (
            <video src={report.previewUrl} controls playsInline className="aspect-square w-full rounded-2xl bg-ink object-contain" />
          ) : (
            <img src={report.previewUrl} alt="" className="aspect-square w-full rounded-2xl bg-ink object-contain" />
          )}
          {report.residualUrl ? (
            <div className="mt-3 flex items-center gap-3">
              <img src={report.residualUrl} alt="" className="h-16 w-16 rounded-xl object-cover" />
              <p className="text-xs text-pretty text-muted">
                Texture map. Brighter marks are fine detail. Smooth generators often look flat here. It is a clue, not a verdict.
              </p>
            </div>
          ) : null}
        </div>
        <div className="p-5 md:p-6">
          <p className="flex items-center gap-2 text-xs text-muted">
            {report.kind === "video" ? <Clapperboard className="h-4 w-4" /> : <ImageIcon className="h-4 w-4" />}
            <span className="truncate">{report.fileName}</span>
          </p>
          <h2 className={`mt-3 inline-flex rounded-full px-3 py-1 text-sm font-medium ${tone(report.verdict)}`}>
            {copy.title}
          </h2>
          <p className="mt-4 font-display text-6xl leading-none font-semibold tabular-nums">{report.score}</p>
          <p className="mt-1 text-sm text-muted">AI likelihood, from a start of 48</p>
          <div className="mt-4 h-2 overflow-hidden rounded-full bg-paper-deep">
            <div className={`h-full ${meter(report.verdict)}`} style={{ width: `${report.score}%` }} />
          </div>
          <p className="mt-4 text-sm text-pretty text-muted">{copy.lede}</p>
        </div>
      </div>

      <div className="border-t border-line px-5 py-5 md:px-6">
        <h3 className="text-sm font-medium">Why this score</h3>
        <p className="mt-1 text-xs text-muted">Positive points lean generated. Negative points lean camera.</p>
        <ul className="mt-4 flex flex-col gap-4">
          {report.signals.map((signal) => (
            <li key={signal.id} className="grid grid-cols-[1fr_auto] gap-3">
              <div>
                <p className="text-sm font-medium">
                  {signal.title}
                  <span className="ml-2 text-xs font-normal text-muted">· {signal.strength}</span>
                </p>
                <p className="mt-1 text-sm text-pretty text-muted">{signal.detail}</p>
              </div>
              <p className={`pt-0.5 text-sm tabular-nums font-medium ${weightTone(signal.weight)}`}>{formatWeight(signal.weight)}</p>
            </li>
          ))}
        </ul>
      </div>

      <dl className="grid grid-cols-2 gap-x-4 gap-y-4 border-t border-line px-5 py-5 sm:grid-cols-3 md:px-6">
        {report.facts.map((fact) => (
          <div key={fact.label}>
            <dt className="text-xs text-muted">{fact.label}</dt>
            <dd className="mt-1 text-sm break-words">{fact.value}</dd>
          </div>
        ))}
      </dl>

      {canAsk ? (
        <div className="border-t border-line px-5 py-5 md:px-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h3 className="text-sm font-medium">Second look</h3>
              <p className="mt-1 max-w-md text-sm text-pretty text-muted">
                Ask Grok to look at a small preview. It can disagree with the file tags. One request, not a proof.
              </p>
            </div>
            <button
              type="button"
              onClick={onAsk}
              disabled={opinion.state === "loading"}
              className="inline-flex min-h-11 items-center justify-center rounded-full border border-line bg-paper px-5 text-sm font-medium disabled:opacity-60"
            >
              {opinion.state === "loading" ? "Looking…" : "Ask Grok"}
            </button>
          </div>
          {opinion.state === "done" ? <OpinionBlock opinion={opinion.result} /> : null}
        </div>
      ) : null}
    </article>
  );
}

function OpinionBlock({ opinion }: { opinion: Opinion }) {
  if (!opinion.ok) return <p className="mt-4 text-sm text-ai">{opinion.error}</p>;
  return (
    <div className="mt-4 rounded-2xl bg-paper-deep p-4">
      <p className="text-sm font-medium">
        {COPY[opinion.verdict].title}
        <span className="ml-2 tabular-nums text-muted">{opinion.aiLikelihood}</span>
      </p>
      <ul className="mt-2 flex flex-col gap-1">
        {opinion.notes.map((note) => (
          <li key={note} className="text-sm text-pretty text-muted">
            {note}
          </li>
        ))}
      </ul>
      <p className="mt-2 text-xs text-muted">{opinion.caveat}</p>
    </div>
  );
}

function tone(verdict: Verdict): string {
  if (verdict === "likely_ai") return "bg-ai-soft text-ai";
  if (verdict === "likely_real") return "bg-real-soft text-real";
  return "bg-mid-soft text-mid";
}

function meter(verdict: Verdict): string {
  if (verdict === "likely_ai") return "bg-ai";
  if (verdict === "likely_real") return "bg-real";
  return "bg-mid";
}

function weightTone(weight: number): string {
  if (weight > 0) return "text-ai";
  if (weight < 0) return "text-real";
  return "text-muted";
}

function formatWeight(weight: number): string {
  if (weight > 0) return `+${weight}`;
  if (weight === 0) return "0";
  return String(weight);
}
