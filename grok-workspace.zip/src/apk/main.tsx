import { createRoot } from "react-dom/client";
import { TrueFrameApp } from "../components/trueframe/app";

const root = document.getElementById("root");
if (root) createRoot(root).render(<TrueFrameApp mode="apk" />);
