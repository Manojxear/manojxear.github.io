export type Opinion =
  | {
      ok: true;
      aiLikelihood: number;
      verdict: "likely_real" | "inconclusive" | "likely_ai";
      notes: string[];
      caveat: string;
    }
  | { ok: false; error: string };
