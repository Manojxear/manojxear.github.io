/** Case-insensitive ASCII search. Returns -1 when absent. */
export function indexOfAscii(
  hay: Uint8Array,
  needle: string,
  from = 0,
  to = hay.length,
): number {
  const n = needle.length;
  if (n === 0) return -1;
  const end = Math.min(hay.length, to) - n;
  const codes = new Uint8Array(n);
  for (let j = 0; j < n; j++) codes[j] = fold(needle.charCodeAt(j));
  outer: for (let i = from; i <= end; i++) {
    for (let j = 0; j < n; j++) {
      if (fold(hay[i + j] ?? 0) !== codes[j]) continue outer;
    }
    return i;
  }
  return -1;
}

function fold(c: number): number {
  return c >= 65 && c <= 90 ? c + 32 : c;
}

export function snippetAround(hay: Uint8Array, at: number, needleLen: number): string {
  const start = Math.max(0, at - 28);
  const end = Math.min(hay.length, at + needleLen + 36);
  let s = "";
  for (let i = start; i < end; i++) {
    const c = hay[i] ?? 0;
    s += c >= 32 && c < 127 ? String.fromCharCode(c) : " ";
  }
  return s.replace(/\s+/g, " ").trim().slice(0, 96);
}

export function asciiSlice(hay: Uint8Array, offset: number, count: number): string {
  let s = "";
  const end = Math.min(hay.length, offset + count);
  for (let i = offset; i < end; i++) {
    const c = hay[i] ?? 0;
    if (c === 0) break;
    s += c >= 32 && c < 127 ? String.fromCharCode(c) : " ";
  }
  return s.trim();
}

export function concatBytes(parts: Uint8Array[]): Uint8Array {
  const n = parts.reduce((sum, p) => sum + p.length, 0);
  const out = new Uint8Array(n);
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}
