import type { PixelStats } from "./types";

const MAX_SIDE = 320;

export function drawSource(
  source: CanvasImageSource,
  width: number,
  height: number,
): { stats: PixelStats; residualUrl: string } | undefined {
  if (!width || !height) return undefined;
  const scale = Math.min(1, MAX_SIDE / Math.max(width, height));
  const w = Math.max(1, Math.round(width * scale));
  const h = Math.max(1, Math.round(height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return undefined;
  ctx.drawImage(source, 0, 0, w, h);
  const image = ctx.getImageData(0, 0, w, h);
  const stats = statsFromImageData(image);
  return { stats, residualUrl: residualDataUrl(image) };
}

export function statsFromImageData(image: ImageData): PixelStats {
  const { width: w, height: h, data } = image;
  const n = w * h;
  const gray = new Float32Array(n);
  for (let p = 0, i = 0; p < n; p++, i += 4) {
    gray[p] = ((data[i] ?? 0) * 0.299 + (data[i + 1] ?? 0) * 0.587 + (data[i + 2] ?? 0) * 0.114) / 255;
  }
  const blur = boxBlur(gray, w, h);
  const residual = new Float32Array(n);
  let sum = 0;
  let sumSq = 0;
  let edge = 0;
  let mid = 0;
  let flatSat = 0;
  let flatCount = 0;
  for (let p = 0; p < n; p++) {
    const r = Math.abs((gray[p] ?? 0) - (blur[p] ?? 0));
    residual[p] = r;
    sum += r;
    sumSq += r * r;
  }
  const mean = sum / n;
  const variance = Math.max(0, sumSq / n - mean * mean);
  const std = Math.sqrt(variance);

  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const p = y * w + x;
      const gx =
        -(gray[p - w - 1] ?? 0) +
        (gray[p - w + 1] ?? 0) -
        2 * (gray[p - 1] ?? 0) +
        2 * (gray[p + 1] ?? 0) -
        (gray[p + w - 1] ?? 0) +
        (gray[p + w + 1] ?? 0);
      const gy =
        -(gray[p - w - 1] ?? 0) -
        2 * (gray[p - w] ?? 0) -
        (gray[p - w + 1] ?? 0) +
        (gray[p + w - 1] ?? 0) +
        2 * (gray[p + w] ?? 0) +
        (gray[p + w + 1] ?? 0);
      const mag = Math.hypot(gx, gy);
      if (mag > 0.55) edge += 1;
      const rv = residual[p] ?? 0;
      if (rv > 0.02 && rv < 0.08) mid += 1;
      if (rv < 0.012) {
        const i = p * 4;
        const R = (data[i] ?? 0) / 255;
        const G = (data[i + 1] ?? 0) / 255;
        const B = (data[i + 2] ?? 0) / 255;
        const max = Math.max(R, G, B);
        const min = Math.min(R, G, B);
        if (max > 0.08) {
          flatSat += (max - min) / max;
          flatCount += 1;
        }
      }
    }
  }
  const inner = Math.max(1, (w - 2) * (h - 2));
  return {
    residualMean: mean,
    residualStd: std,
    blockCv: blockCv(residual, w, h),
    edgeRatio: edge / inner,
    midRatio: mid / inner,
    flatSaturation: flatCount > 40 ? flatSat / flatCount : 0,
  };
}

function residualDataUrl(image: ImageData): string {
  const { width: w, height: h, data } = image;
  const canvas = document.createElement("canvas");
  const side = 200;
  const scale = Math.min(1, side / Math.max(w, h));
  canvas.width = Math.max(1, Math.round(w * scale));
  canvas.height = Math.max(1, Math.round(h * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";
  const out = ctx.createImageData(w, h);
  const gray = new Float32Array(w * h);
  for (let p = 0, i = 0; p < gray.length; p++, i += 4) {
    gray[p] = ((data[i] ?? 0) * 0.299 + (data[i + 1] ?? 0) * 0.587 + (data[i + 2] ?? 0) * 0.114) / 255;
  }
  const blur = boxBlur(gray, w, h);
  for (let p = 0, i = 0; p < gray.length; p++, i += 4) {
    const amp = Math.min(255, Math.abs((gray[p] ?? 0) - (blur[p] ?? 0)) * 1400);
    out.data[i] = 80 + amp * 0.55;
    out.data[i + 1] = 62 + amp * 0.28;
    out.data[i + 2] = 42;
    out.data[i + 3] = 255;
  }
  const src = document.createElement("canvas");
  src.width = w;
  src.height = h;
  src.getContext("2d")?.putImageData(out, 0, 0);
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(src, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", 0.72);
}

function blockCv(residual: Float32Array, w: number, h: number): number {
  const size = 16;
  const means: number[] = [];
  for (let y = 0; y + size <= h; y += size) {
    for (let x = 0; x + size <= w; x += size) {
      let s = 0;
      for (let yy = 0; yy < size; yy++) {
        const row = (y + yy) * w + x;
        for (let xx = 0; xx < size; xx++) s += residual[row + xx] ?? 0;
      }
      means.push(s / (size * size));
    }
  }
  if (means.length < 4) return 0;
  const mean = means.reduce((a, b) => a + b, 0) / means.length;
  if (mean < 1e-6) return 0;
  const variance = means.reduce((a, b) => a + (b - mean) ** 2, 0) / means.length;
  return Math.sqrt(variance) / mean;
}

function boxBlur(src: Float32Array, w: number, h: number): Float32Array {
  const tmp = new Float32Array(src.length);
  const dst = new Float32Array(src.length);
  for (let y = 0; y < h; y++) {
    const row = y * w;
    for (let x = 0; x < w; x++) {
      const a = src[row + (x > 0 ? x - 1 : x)] ?? 0;
      const b = src[row + x] ?? 0;
      const c = src[row + (x + 1 < w ? x + 1 : x)] ?? 0;
      tmp[row + x] = (a + b + c) / 3;
    }
  }
  for (let x = 0; x < w; x++) {
    for (let y = 0; y < h; y++) {
      const y0 = y > 0 ? y - 1 : y;
      const y1 = y + 1 < h ? y + 1 : y;
      dst[y * w + x] = ((tmp[y0 * w + x] ?? 0) + (tmp[y * w + x] ?? 0) + (tmp[y1 * w + x] ?? 0)) / 3;
    }
  }
  return dst;
}

export async function jpegDataUrl(source: CanvasImageSource, width: number, height: number): Promise<string> {
  const max = 640;
  const scale = Math.min(1, max / Math.max(width, height, 1));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(width * scale));
  canvas.height = Math.max(1, Math.round(height * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";
  ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", 0.62);
}
