export type GeneratorPattern = { label: string; needles: string[] };

/** Longer phrases only. Short words false-match compressed bytes. */
export const GENERATORS: GeneratorPattern[] = [
  { label: "Midjourney", needles: ["midjourney"] },
  {
    label: "Stable Diffusion",
    needles: [
      "stable diffusion",
      "stablediffusion",
      "novelai",
      "comfyui",
      "automatic1111",
      "invokeai",
      "fooocus",
      "tensor.art",
      "civitai",
    ],
  },
  { label: "DALL·E", needles: ["dall-e", "dalle-2", "dalle-3", "dall·e"] },
  { label: "ChatGPT image", needles: ["gpt-image", "chatgpt image"] },
  { label: "Adobe Firefly", needles: ["adobe firefly", "firefly"] },
  { label: "Ideogram", needles: ["ideogram"] },
  { label: "Leonardo", needles: ["leonardo.ai", "leonardo ai"] },
  { label: "Flux", needles: ["flux.1", "black forest labs"] },
  { label: "Google Imagen", needles: ["imagen 3", "imagen-3", "imagen 4", "imagen-4"] },
  { label: "Grok image", needles: ["grok-imagine", "grok image"] },
  { label: "Runway", needles: ["runwayml", "runway gen", "gen-3 alpha"] },
  { label: "Kling", needles: ["kling ai", "klingai"] },
  { label: "Pika", needles: ["pika.art", "pika labs"] },
  { label: "Luma", needles: ["lumalabs", "luma dream machine"] },
  { label: "OpenAI Sora", needles: ["openai sora"] },
  { label: "Google Veo", needles: ["google veo", "veo-2", "veo-3"] },
  { label: "Haiper", needles: ["haiper.ai"] },
  { label: "Synthesia", needles: ["synthesia"] },
  { label: "HeyGen", needles: ["heygen"] },
  { label: "Dreamina", needles: ["dreamina"] },
  { label: "Recraft", needles: ["recraft.ai"] },
  { label: "NightCafe", needles: ["nightcafe"] },
  { label: "SeaArt", needles: ["seaart.ai"] },
  { label: "Microsoft Designer", needles: ["microsoft designer", "bing image creator"] },
  { label: "Meta AI", needles: ["make-a-video", "meta ai imagine"] },
];

export const GENERATIVE_EDIT_NEEDLES = ["generative fill", "generative expand"];

export const EDITORS: { label: string; needles: string[] }[] = [
  { label: "Photoshop", needles: ["adobe photoshop"] },
  { label: "Lightroom", needles: ["adobe photoshop lightroom", "lightroom"] },
  { label: "Snapseed", needles: ["snapseed"] },
  { label: "GIMP", needles: ["gimp"] },
  { label: "Capture One", needles: ["capture one"] },
  { label: "Affinity Photo", needles: ["affinity photo"] },
  { label: "VSCO", needles: ["vsco"] },
];

export const CAMERA_MAKES = [
  "apple",
  "canon",
  "nikon",
  "sony",
  "fujifilm",
  "fuji photo film",
  "olympus",
  "om digital",
  "panasonic",
  "leica",
  "hasselblad",
  "phase one",
  "ricoh",
  "pentax",
  "gopro",
  "dji",
  "samsung",
  "google",
  "motorola",
  "huawei",
  "xiaomi",
  "oneplus",
  "oppo",
  "vivo",
  "honor",
  "tcl",
  "kodak",
  "casio",
  "sigma",
  "hmd global",
  "lge",
  "lg electronics",
  "blackmagic",
  "zeiss",
  "nokia",
];

/** Common generator canvases. Phone screenshots are intentionally absent. */
const AI_LONG = new Set([
  512, 576, 640, 704, 768, 832, 896, 960, 1024, 1088, 1152, 1216, 1280, 1344, 1408, 1472, 1536,
  1600, 1664, 1728, 1792, 1920, 2048, 2304, 2560,
]);

const AI_PAIRS: [number, number][] = [
  [832, 1216],
  [896, 1152],
  [768, 1344],
  [640, 1536],
  [1024, 1536],
  [1024, 1792],
  [1024, 1360],
  [768, 1024],
  [512, 768],
  [720, 1280],
  [1280, 720],
];

export function isSyntheticCanvas(width: number, height: number): boolean {
  if (!width || !height) return false;
  const a = Math.min(width, height);
  const b = Math.max(width, height);
  if (width === height && AI_LONG.has(width)) return true;
  return AI_PAIRS.some(([w, h]) => (a === Math.min(w, h) && b === Math.max(w, h)));
}

export function isKnownCameraMake(make: string | undefined): boolean {
  if (!make) return false;
  const m = make.trim().toLowerCase();
  return CAMERA_MAKES.some((c) => m === c || m.startsWith(`${c} `) || m.includes(c));
}
