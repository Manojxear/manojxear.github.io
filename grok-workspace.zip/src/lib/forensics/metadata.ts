import { asciiSlice, indexOfAscii, snippetAround } from "./bytes";
import {
  EDITORS,
  GENERATIVE_EDIT_NEEDLES,
  GENERATORS,
  isKnownCameraMake,
  isSyntheticCanvas,
  type GeneratorPattern,
} from "./signatures";
import type { Evidence, GeneratorHit } from "./types";

export type ContainerInfo = {
  format: string;
  width?: number;
  height?: number;
  texts: string[];
  make?: string;
  model?: string;
  software?: string;
  lens?: string;
  exposure?: string;
  taken?: string;
  hasGps: boolean;
  parameterChunk: boolean;
};

const EMPTY: ContainerInfo = { format: "Unknown", texts: [], hasGps: false, parameterChunk: false };

export function inspectFile(head: Uint8Array, tail: Uint8Array): ContainerInfo {
  try {
    if (isJpeg(head)) return inspectJpeg(head);
    if (isPng(head)) return inspectPng(head);
    if (isWebp(head)) return inspectWebp(head);
    if (isGif(head)) return { ...EMPTY, format: "GIF", texts: collectTexts(head, tail) };
    if (isWebm(head)) return { ...EMPTY, format: "WebM", texts: collectTexts(head, tail) };
    if (isIsoBmff(head) || isIsoBmff(tail)) {
      return { ...EMPTY, format: isoBrand(head) ?? isoBrand(tail) ?? "MP4", texts: collectTexts(head, tail) };
    }
    return { ...EMPTY, format: "File", texts: collectTexts(head, tail) };
  } catch {
    return { ...EMPTY, format: "File", texts: collectTexts(head, tail) };
  }
}

export function evidenceFromContainer(
  kind: "image" | "video",
  info: ContainerInfo,
  extraText: string[] = [],
): Evidence {
  const corpus = [info.software, info.make, info.model, info.lens, ...info.texts, ...extraText].filter(
    (t): t is string => Boolean(t && t.trim()),
  );
  const generators = findGenerators(corpus);
  const generativeFill = corpus.some((t) =>
    GENERATIVE_EDIT_NEEDLES.some((n) => t.toLowerCase().includes(n)),
  );
  const sdParameters =
    info.parameterChunk ||
    corpus.some((t) => {
      const s = t.toLowerCase();
      return s.includes("steps:") && s.includes("sampler:") && (s.includes("cfg scale") || s.includes("cfg:"));
    });
  const c2pa = c2paKind(corpus);
  const editor = findEditor(corpus);
  const make = clean(info.make);
  const model = clean(info.model);
  return {
    kind,
    generators,
    sdParameters,
    generativeFill,
    c2pa,
    cameraMake: isKnownCameraMake(make) ? make : make || undefined,
    cameraModel: model,
    software: clean(info.software),
    lens: clean(info.lens),
    exposure: info.exposure,
    taken: info.taken,
    hasGps: info.hasGps,
    editor,
    syntheticSize: isSyntheticCanvas(info.width ?? 0, info.height ?? 0),
  };
}

function findGenerators(texts: string[]): GeneratorHit[] {
  const hits: GeneratorHit[] = [];
  const seen = new Set<string>();
  for (const pattern of GENERATORS) {
    const hit = matchPattern(texts, pattern);
    if (hit && !seen.has(hit.label)) {
      seen.add(hit.label);
      hits.push(hit);
    }
  }
  return hits;
}

function matchPattern(texts: string[], pattern: GeneratorPattern): GeneratorHit | undefined {
  for (const text of texts) {
    const lower = text.toLowerCase();
    for (const needle of pattern.needles) {
      const at = lower.indexOf(needle);
      if (at >= 0) {
        const raw = text.slice(Math.max(0, at - 24), at + needle.length + 32);
        return { label: pattern.label, snippet: raw.replace(/\s+/g, " ").trim().slice(0, 96) };
      }
    }
  }
  return undefined;
}

function findEditor(texts: string[]): string | undefined {
  const blob = texts.join("\n").toLowerCase();
  for (const editor of EDITORS) {
    if (editor.needles.some((n) => blob.includes(n))) return editor.label;
  }
  return undefined;
}

function c2paKind(texts: string[]): Evidence["c2pa"] {
  const blob = texts.join("\n").toLowerCase();
  if (blob.includes("trainedalgorithmicmedia") || blob.includes("compositesynthetic")) return "trained";
  if (blob.includes("digitalcapture")) return "capture";
  if (blob.includes("c2pa") || blob.includes("contentcredentials") || blob.includes("jumbf")) return "present";
  return "none";
}

function collectTexts(head: Uint8Array, tail: Uint8Array): string[] {
  return [latinWindow(head), latinWindow(tail)].filter((s) => s.length > 0);
}

function latinWindow(bytes: Uint8Array): string {
  let s = "";
  for (let i = 0; i < bytes.length; i++) {
    const c = bytes[i] ?? 0;
    s += c >= 32 && c < 127 ? String.fromCharCode(c) : "\n";
  }
  return s;
}

function clean(value: string | undefined): string | undefined {
  const v = value?.replace(/\s+/g, " ").trim();
  return v ? v.slice(0, 120) : undefined;
}

function isJpeg(b: Uint8Array): boolean {
  return b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff;
}
function isPng(b: Uint8Array): boolean {
  return b.length > 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47;
}
function isGif(b: Uint8Array): boolean {
  return indexOfAscii(b, "GIF8", 0, 6) === 0;
}
function isWebp(b: Uint8Array): boolean {
  return indexOfAscii(b, "RIFF", 0, 4) === 0 && indexOfAscii(b, "WEBP", 8, 12) === 8;
}
function isWebm(b: Uint8Array): boolean {
  return b.length > 4 && b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3;
}
function isIsoBmff(b: Uint8Array): boolean {
  return indexOfAscii(b, "ftyp", 4, 12) === 4;
}

function isoBrand(b: Uint8Array): string | undefined {
  if (!isIsoBmff(b)) return undefined;
  const brand = asciiSlice(b, 8, 4).toLowerCase();
  if (brand.startsWith("qt")) return "MOV";
  if (brand.includes("web")) return "WebM";
  return "MP4";
}

function inspectJpeg(bytes: Uint8Array): ContainerInfo {
  const info: ContainerInfo = { format: "JPEG", texts: [], hasGps: false, parameterChunk: false };
  let o = 2;
  while (o + 4 < bytes.length) {
    if (bytes[o] !== 0xff) {
      o += 1;
      continue;
    }
    const marker = bytes[o + 1] ?? 0;
    if (marker === 0xd9 || marker === 0xda) break;
    if (marker === 0x00 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd8)) {
      o += 2;
      continue;
    }
    if (o + 4 > bytes.length) break;
    const size = ((bytes[o + 2] ?? 0) << 8) | (bytes[o + 3] ?? 0);
    if (size < 2 || o + 2 + size > bytes.length) break;
    const start = o + 4;
    const end = o + 2 + size;
    if (marker === 0xfe) info.texts.push(asciiSlice(bytes, start, end - start));
    if (marker >= 0xe0 && marker <= 0xef) absorbApp(info, bytes, start, end);
    if (
      (marker >= 0xc0 && marker <= 0xc3) ||
      (marker >= 0xc5 && marker <= 0xc7) ||
      (marker >= 0xc9 && marker <= 0xcb)
    ) {
      if (end - start >= 6) {
        info.height = ((bytes[start + 1] ?? 0) << 8) | (bytes[start + 2] ?? 0);
        info.width = ((bytes[start + 3] ?? 0) << 8) | (bytes[start + 4] ?? 0);
      }
    }
    o = end;
  }
  info.texts.push(latinWindow(bytes.subarray(0, Math.min(bytes.length, 196_608))));
  return info;
}

function absorbApp(info: ContainerInfo, bytes: Uint8Array, start: number, end: number) {
  if (indexOfAscii(bytes, "Exif", start, start + 6) === start) {
    readExif(info, bytes, start + 6);
    return;
  }
  if (indexOfAscii(bytes, "http://ns.adobe.com/xap", start, start + 32) === start) {
    const zero = bytes.indexOf(0, start);
    const textStart = zero > start && zero < end ? zero + 1 : start;
    info.texts.push(asciiSlice(bytes, textStart, end - textStart));
    return;
  }
  info.texts.push(asciiSlice(bytes, start, Math.min(4000, end - start)));
}

function inspectPng(bytes: Uint8Array): ContainerInfo {
  const info: ContainerInfo = { format: "PNG", texts: [], hasGps: false, parameterChunk: false };
  let o = 8;
  while (o + 12 <= bytes.length) {
    const length = readU32(bytes, o);
    const type = asciiSlice(bytes, o + 4, 4);
    const data = o + 8;
    if (length < 0 || data + length + 4 > bytes.length) break;
    if (type === "IHDR" && length >= 8) {
      info.width = readU32(bytes, data);
      info.height = readU32(bytes, data + 4);
    } else if (type === "tEXt" || type === "iTXt") {
      const text = latinLen(bytes, data, length);
      info.texts.push(text);
      if (/^parameters\b/i.test(text)) info.parameterChunk = true;
    } else if (type === "zTXt") {
      const key = asciiSlice(bytes, data, length);
      info.texts.push(key);
      if (/^parameters$/i.test(key)) info.parameterChunk = true;
    } else if (type === "eXIf") {
      readExif(info, bytes, data);
    } else if (type === "tIME" || type === "caBX" || type.startsWith("ca")) {
      info.texts.push(asciiSlice(bytes, data, Math.min(length, 8000)));
    }
    o = data + length + 4;
  }
  return info;
}

function latinLen(bytes: Uint8Array, offset: number, count: number): string {
  let s = "";
  const end = Math.min(bytes.length, offset + count);
  for (let i = offset; i < end; i++) {
    const c = bytes[i] ?? 0;
    s += c >= 32 && c < 127 ? String.fromCharCode(c) : " ";
  }
  return s.replace(/\s+/g, " ").trim();
}

function inspectWebp(bytes: Uint8Array): ContainerInfo {
  const info: ContainerInfo = {
    format: "WebP",
    texts: [latinWindow(bytes.subarray(0, Math.min(bytes.length, 196_608)))],
    hasGps: false,
    parameterChunk: false,
  };
  let o = 12;
  while (o + 8 <= bytes.length) {
    const type = asciiSlice(bytes, o, 4);
    const size = readU32le(bytes, o + 4);
    const data = o + 8;
    if (size < 0 || data + size > bytes.length + 1) break;
    if (type === "EXIF") {
      if (indexOfAscii(bytes, "Exif", data, data + 6) === data) readExif(info, bytes, data + 6);
      else readExif(info, bytes, data);
    }
    if (type === "XMP " || type === "XMP") info.texts.push(latinLen(bytes, data, Math.min(size, 8000)));
    const padded = size + (size % 2);
    o = data + padded;
  }
  return info;
}

function readU32(bytes: Uint8Array, o: number): number {
  return (
    ((bytes[o] ?? 0) << 24) |
    ((bytes[o + 1] ?? 0) << 16) |
    ((bytes[o + 2] ?? 0) << 8) |
    (bytes[o + 3] ?? 0)
  ) >>> 0;
}
function readU32le(bytes: Uint8Array, o: number): number {
  return (
    (bytes[o] ?? 0) |
    ((bytes[o + 1] ?? 0) << 8) |
    ((bytes[o + 2] ?? 0) << 16) |
    ((bytes[o + 3] ?? 0) << 24)
  ) >>> 0;
}

function readExif(info: ContainerInfo, bytes: Uint8Array, tiff: number) {
  if (tiff + 8 > bytes.length) return;
  const le = bytes[tiff] === 0x49 && bytes[tiff + 1] === 0x49;
  const be = bytes[tiff] === 0x4d && bytes[tiff + 1] === 0x4d;
  if (!le && !be) return;
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const magic = view.getUint16(tiff + 2, le);
  if (magic !== 42) return;
  const ifd0 = view.getUint32(tiff + 4, le);
  walkIfd(info, view, tiff, ifd0, le, 0);
}

function walkIfd(
  info: ContainerInfo,
  view: DataView,
  tiff: number,
  ifdOffset: number,
  le: boolean,
  depth: number,
) {
  if (depth > 4) return;
  const abs = tiff + ifdOffset;
  if (abs < 0 || abs + 2 > view.byteLength) return;
  let count = 0;
  try {
    count = view.getUint16(abs, le);
  } catch {
    return;
  }
  if (count > 256) return;
  for (let i = 0; i < count; i++) {
    const e = abs + 2 + i * 12;
    if (e + 12 > view.byteLength) return;
    const tag = view.getUint16(e, le);
    const type = view.getUint16(e + 2, le);
    const n = view.getUint32(e + 4, le);
    const value = readTag(view, tiff, e + 8, type, n, le);
    applyTag(info, tag, value, view, tiff, le, depth);
  }
}

function applyTag(
  info: ContainerInfo,
  tag: number,
  value: string | undefined,
  view: DataView,
  tiff: number,
  le: boolean,
  depth: number,
) {
  if (tag === 271 && value) info.make = value;
  else if (tag === 272 && value) info.model = value;
  else if (tag === 305 && value) info.software = value;
  else if (tag === 306 && value && !info.taken) info.taken = value;
  else if (tag === 36867 && value) info.taken = value;
  else if (tag === 42036 && value) info.lens = value;
  else if (tag === 270 && value) info.texts.push(value);
  else if (tag === 315 && value) info.texts.push(value);
  else if (tag === 33432 && value) info.texts.push(value);
  else if (tag === 37510 && value) info.texts.push(value);
  else if ((tag === 34665 || tag === 34853 || tag === 40965) && value && /^\d+$/.test(value)) {
    if (tag === 34853) info.hasGps = true;
    else walkIfd(info, view, tiff, Number(value), le, depth + 1);
  } else if (tag === 33437 || tag === 33434 || tag === 34855 || tag === 37386) {
    const piece = formatExposurePiece(tag, value);
    if (piece) info.exposure = info.exposure ? `${info.exposure} · ${piece}` : piece;
  }
}

function formatExposurePiece(tag: number, value: string | undefined): string | undefined {
  if (!value) return undefined;
  if (tag === 33437) return `f/${trimNum(value)}`;
  if (tag === 37386) return `${trimNum(value)}mm`;
  if (tag === 34855) return `ISO ${value}`;
  if (tag === 33434) {
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return undefined;
    if (n >= 1) return `${trimNum(String(n))}s`;
    return `1/${Math.round(1 / n)}s`;
  }
  return undefined;
}

function trimNum(value: string): string {
  const n = Number(value);
  if (!Number.isFinite(n)) return value;
  return String(Math.round(n * 100) / 100);
}

function readTag(
  view: DataView,
  tiff: number,
  valueField: number,
  type: number,
  count: number,
  le: boolean,
): string | undefined {
  const unit = typeSize(type);
  if (!unit || count <= 0 || count > 8_000_000) return undefined;
  const bytes = unit * count;
  let pos = valueField;
  if (bytes > 4) {
    const ptr = view.getUint32(valueField, le);
    pos = tiff + ptr;
  }
  if (pos < 0 || pos + Math.min(bytes, 4) > view.byteLength) return undefined;
  if (type === 2) {
    const n = Math.min(count, 400);
    if (pos + n > view.byteLength) return undefined;
    let s = "";
    for (let i = 0; i < n; i++) {
      const c = view.getUint8(pos + i);
      if (c === 0) break;
      s += c >= 32 && c < 127 ? String.fromCharCode(c) : " ";
    }
    return s.trim();
  }
  if (type === 3 && count >= 1) return String(view.getUint16(pos, le));
  if (type === 4 && count >= 1) return String(view.getUint32(pos, le));
  if (type === 5 && count >= 1 && pos + 8 <= view.byteLength) {
    const num = view.getUint32(pos, le);
    const den = view.getUint32(pos + 4, le);
    if (!den) return undefined;
    return String(num / den);
  }
  if (type === 10 && count >= 1 && pos + 8 <= view.byteLength) {
    const num = view.getInt32(pos, le);
    const den = view.getInt32(pos + 4, le);
    if (!den) return undefined;
    return String(num / den);
  }
  if ((type === 1 || type === 7) && count < 64) return undefined;
  if (type === 7 && count > 8) {
    const n = Math.min(count, 240);
    if (pos + n > view.byteLength) return undefined;
    return snippetAround(new Uint8Array(view.buffer, view.byteOffset + pos, n), 0, n);
  }
  return undefined;
}

function typeSize(type: number): number {
  switch (type) {
    case 1:
    case 2:
    case 6:
    case 7:
      return 1;
    case 3:
    case 8:
      return 2;
    case 4:
    case 9:
    case 11:
      return 4;
    case 5:
    case 10:
    case 12:
      return 8;
    default:
      return 0;
  }
}

export function hitInBytes(bytes: Uint8Array, needle: string): string | undefined {
  const at = indexOfAscii(bytes, needle);
  if (at < 0) return undefined;
  return snippetAround(bytes, at, needle.length);
}
