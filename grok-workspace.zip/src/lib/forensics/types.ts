export type Verdict = "likely_real" | "inconclusive" | "likely_ai";

export type SignalStrength = "strong" | "moderate" | "hint";

export type Signal = {
  id: string;
  title: string;
  detail: string;
  /** Positive pushes toward generated. Negative pushes toward a camera. */
  weight: number;
  strength: SignalStrength;
};

export type Fact = { label: string; value: string };

export type PixelStats = {
  residualMean: number;
  residualStd: number;
  blockCv: number;
  edgeRatio: number;
  midRatio: number;
  flatSaturation: number;
};

export type GeneratorHit = {
  label: string;
  snippet: string;
};

export type Evidence = {
  kind: "image" | "video";
  generators: GeneratorHit[];
  sdParameters: boolean;
  generativeFill: boolean;
  c2pa: "none" | "trained" | "capture" | "present";
  cameraMake?: string;
  cameraModel?: string;
  software?: string;
  lens?: string;
  exposure?: string;
  taken?: string;
  hasGps: boolean;
  editor?: string;
  syntheticSize: boolean;
  pixel?: PixelStats;
  framesSampled?: number;
  frameSpread?: number;
  decodeFailed?: boolean;
};

export type Report = {
  id: string;
  kind: "image" | "video";
  fileName: string;
  mime: string;
  byteLength: number;
  width?: number;
  height?: number;
  durationSec?: number;
  verdict: Verdict;
  score: number;
  signals: Signal[];
  facts: Fact[];
  previewUrl: string;
  residualUrl?: string;
  framesSampled?: number;
};
