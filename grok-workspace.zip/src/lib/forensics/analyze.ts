import { evidenceFromContainer, inspectFile, type ContainerInfo } from "./metadata";
import { drawSource, jpegDataUrl } from "./pixels";
import { judge } from "./judge";
import { isSyntheticCanvas } from "./signatures";
import type { Evidence, Fact, PixelStats, Report } from "./types";

const IMAGE_MAX = 32 * 1024 * 1024;
const VIDEO_MAX = 120 * 1024 * 1024;
const IMAGE_SCAN = 12 * 1024 * 1024;
const VIDEO_HEAD = 4 * 1024 * 1024;
const VIDEO_TAIL = 2 * 1024 * 1024;

export type ProgressFn = (label: string, ratio: number) => void;

export async function analyzeFile(file: File, onProgress?: ProgressFn): Promise<Report> {
  const kind = kindOf(file);
  if (kind === "unknown") {
    throw new Error("Use a photo (JPG, PNG, WEBP, GIF) or a video (MP4, WEBM, MOV).");
  }
  const limit = kind === "image" ? IMAGE_MAX : VIDEO_MAX;
  if (file.size > limit) {
    throw new Error(kind === "image" ? "That image is over 32 MB." : "That video is over 120 MB.");
  }

  onProgress?.("Reading the file", 0.12);
  const { head, tail } = await readEdges(file, kind);
  onProgress?.("Checking tags and metadata", 0.32);
  const info = inspectFile(head, tail);
  const evidence = evidenceFromContainer(kind, info);
  const previewUrl = URL.createObjectURL(file);

  try {
    if (kind === "image") {
      onProgress?.("Reading texture", 0.62);
      const decoded = await decodeImage(file, info, evidence);
      onProgress?.("Scoring", 0.9);
      return finish(file, kind, info, evidence, previewUrl, decoded?.residualUrl, decoded?.width, decoded?.height);
    }
    onProgress?.("Sampling frames", 0.5);
    const video = await sampleVideo(previewUrl, evidence, onProgress);
    onProgress?.("Scoring", 0.9);
    return finish(
      file,
      kind,
      info,
      evidence,
      previewUrl,
      video.residualUrl,
      video.width,
      video.height,
      video.duration,
    );
  } catch (error) {
    URL.revokeObjectURL(previewUrl);
    throw error;
  }
}

export async function opinionJpegs(file: File): Promise<string[]> {
  const kind = kindOf(file);
  if (kind === "image") {
    const bitmap = await createImageBitmap(file);
    try {
      const url = await jpegDataUrl(bitmap, bitmap.width, bitmap.height);
      return url ? [url] : [];
    } finally {
      bitmap.close();
    }
  }
  if (kind !== "video") return [];
  const url = URL.createObjectURL(file);
  const video = document.createElement("video");
  video.muted = true;
  video.playsInline = true;
  video.preload = "auto";
  video.src = url;
  try {
    await waitMedia(video, "loadeddata");
    const duration = Number.isFinite(video.duration) ? video.duration : 0;
    const times = duration > 0 ? [0.2, 0.5, 0.8].map((p) => Math.min(duration * p, Math.max(0, duration - 0.05))) : [0];
    const out: string[] = [];
    for (const time of times) {
      await seekTo(video, time);
      const jpeg = await jpegDataUrl(video, video.videoWidth, video.videoHeight);
      if (jpeg) out.push(jpeg);
    }
    return out;
  } finally {
    video.src = "";
    URL.revokeObjectURL(url);
  }
}

function finish(
  file: File,
  kind: "image" | "video",
  info: ContainerInfo,
  evidence: Evidence,
  previewUrl: string,
  residualUrl: string | undefined,
  width?: number,
  height?: number,
  durationSec?: number,
): Report {
  if (width && height) evidence.syntheticSize = isSyntheticCanvas(width, height);
  const judged = judge(evidence);
  return {
    id: crypto.randomUUID(),
    kind,
    fileName: file.name || (kind === "image" ? "image" : "video"),
    mime: file.type || info.format,
    byteLength: file.size,
    width,
    height,
    durationSec,
    verdict: judged.verdict,
    score: judged.score,
    signals: judged.signals,
    facts: buildFacts(file, info, evidence, width, height, durationSec),
    previewUrl,
    residualUrl: residualUrl || undefined,
    framesSampled: evidence.framesSampled,
  };
}

async function decodeImage(file: File, info: ContainerInfo, evidence: Evidence) {
  try {
    const bitmap = await createImageBitmap(file);
    try {
      const drawn = drawSource(bitmap, bitmap.width, bitmap.height);
      if (!drawn) {
        evidence.decodeFailed = true;
        return { width: bitmap.width || info.width, height: bitmap.height || info.height, residualUrl: undefined };
      }
      evidence.pixel = drawn.stats;
      return { width: bitmap.width, height: bitmap.height, residualUrl: drawn.residualUrl };
    } finally {
      bitmap.close();
    }
  } catch {
    evidence.decodeFailed = true;
    return { width: info.width, height: info.height, residualUrl: undefined };
  }
}

async function sampleVideo(
  previewUrl: string,
  evidence: Evidence,
  onProgress?: ProgressFn,
): Promise<{ width?: number; height?: number; duration?: number; residualUrl?: string }> {
  const video = document.createElement("video");
  video.muted = true;
  video.playsInline = true;
  video.preload = "auto";
  video.src = previewUrl;
  try {
    await waitMedia(video, "loadeddata");
  } catch {
    evidence.decodeFailed = true;
    return {};
  }
  const width = video.videoWidth || undefined;
  const height = video.videoHeight || undefined;
  const duration = Number.isFinite(video.duration) ? video.duration : undefined;
  const fractions = [0.12, 0.32, 0.5, 0.68, 0.88];
  const stats: PixelStats[] = [];
  let residualUrl: string | undefined;
  for (let i = 0; i < fractions.length; i++) {
    const frac = fractions[i] ?? 0.5;
    const time = duration ? Math.min(duration * frac, Math.max(0, duration - 0.05)) : 0;
    try {
      await seekTo(video, time);
    } catch {
      break;
    }
    const drawn = width && height ? drawSource(video, width, height) : undefined;
    if (drawn) {
      stats.push(drawn.stats);
      if (i === 2) residualUrl = drawn.residualUrl;
    }
    onProgress?.(`Sampling frame ${i + 1} of ${fractions.length}`, 0.5 + i * 0.08);
  }
  if (!residualUrl && stats.length === 0) {
    const drawn = width && height ? drawSource(video, width, height) : undefined;
    if (drawn) {
      stats.push(drawn.stats);
      residualUrl = drawn.residualUrl;
    }
  }
  if (stats.length === 0) evidence.decodeFailed = true;
  else {
    evidence.pixel = averageStats(stats);
    evidence.framesSampled = stats.length;
    evidence.frameSpread = spread(stats.map((s) => s.residualStd)) * 1000;
  }
  video.src = "";
  return { width, height, duration, residualUrl };
}

function averageStats(list: PixelStats[]): PixelStats {
  const n = list.length;
  const acc: PixelStats = {
    residualMean: 0,
    residualStd: 0,
    blockCv: 0,
    edgeRatio: 0,
    midRatio: 0,
    flatSaturation: 0,
  };
  for (const s of list) {
    acc.residualMean += s.residualMean;
    acc.residualStd += s.residualStd;
    acc.blockCv += s.blockCv;
    acc.edgeRatio += s.edgeRatio;
    acc.midRatio += s.midRatio;
    acc.flatSaturation += s.flatSaturation;
  }
  acc.residualMean /= n;
  acc.residualStd /= n;
  acc.blockCv /= n;
  acc.edgeRatio /= n;
  acc.midRatio /= n;
  acc.flatSaturation /= n;
  return acc;
}

function spread(values: number[]): number {
  if (values.length < 2) return 0;
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance = values.reduce((a, b) => a + (b - mean) ** 2, 0) / values.length;
  return Math.sqrt(variance);
}

function buildFacts(
  file: File,
  info: ContainerInfo,
  evidence: Evidence,
  width?: number,
  height?: number,
  durationSec?: number,
): Fact[] {
  const facts: Fact[] = [
    { label: "Format", value: info.format },
    { label: "Size", value: formatBytes(file.size) },
  ];
  if (width && height) facts.push({ label: "Dimensions", value: `${width} × ${height}` });
  if (durationSec !== undefined) facts.push({ label: "Duration", value: formatDuration(durationSec) });
  const camera = [evidence.cameraMake, evidence.cameraModel].filter(Boolean).join(" ");
  if (camera) facts.push({ label: "Device", value: camera });
  if (evidence.lens) facts.push({ label: "Lens", value: evidence.lens });
  if (evidence.exposure) facts.push({ label: "Exposure", value: evidence.exposure });
  if (evidence.taken) facts.push({ label: "Taken", value: evidence.taken });
  if (evidence.software) facts.push({ label: "Software", value: evidence.software });
  if (evidence.framesSampled) facts.push({ label: "Frames checked", value: String(evidence.framesSampled) });
  return facts;
}

async function readEdges(file: File, kind: "image" | "video"): Promise<{ head: Uint8Array; tail: Uint8Array }> {
  if (kind === "image") {
    const head = new Uint8Array(await file.slice(0, Math.min(file.size, IMAGE_SCAN)).arrayBuffer());
    const tailStart = Math.max(0, file.size - 64_000);
    const tail =
      file.size > IMAGE_SCAN ? new Uint8Array(await file.slice(tailStart).arrayBuffer()) : new Uint8Array();
    return { head, tail };
  }
  const head = new Uint8Array(await file.slice(0, Math.min(file.size, VIDEO_HEAD)).arrayBuffer());
  const tail =
    file.size > VIDEO_HEAD
      ? new Uint8Array(await file.slice(Math.max(0, file.size - VIDEO_TAIL)).arrayBuffer())
      : new Uint8Array();
  return { head, tail };
}

export function kindOf(file: File): "image" | "video" | "unknown" {
  const type = file.type.toLowerCase();
  if (type.startsWith("image/")) return "image";
  if (type.startsWith("video/")) return "video";
  const name = file.name.toLowerCase();
  if (/\.(jpe?g|png|webp|gif|bmp|avif)$/.test(name)) return "image";
  if (/\.(mp4|webm|mov|m4v|mkv)$/.test(name)) return "video";
  return "unknown";
}

function waitMedia(el: HTMLMediaElement, event: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = window.setTimeout(() => reject(new Error("This video took too long to open.")), 12_000);
    const done = () => {
      window.clearTimeout(timer);
      resolve();
    };
    const fail = () => {
      window.clearTimeout(timer);
      reject(new Error("This video could not be played in the browser."));
    };
    el.addEventListener(event, done, { once: true });
    el.addEventListener("error", fail, { once: true });
  });
}

function seekTo(video: HTMLVideoElement, time: number): Promise<void> {
  if (Math.abs(video.currentTime - time) < 0.08 && video.readyState >= 2) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const timer = window.setTimeout(() => reject(new Error("Could not step through this video.")), 8_000);
    const done = () => {
      window.clearTimeout(timer);
      resolve();
    };
    video.addEventListener("seeked", done, { once: true });
    try {
      video.currentTime = time;
    } catch {
      window.clearTimeout(timer);
      reject(new Error("Could not step through this video."));
    }
  });
}

function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function formatDuration(sec: number): string {
  const s = Math.round(sec);
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${r.toString().padStart(2, "0")}`;
}
