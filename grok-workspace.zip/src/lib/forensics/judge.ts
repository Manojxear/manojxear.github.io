import { isKnownCameraMake } from "./signatures";
import type { Evidence, PixelStats, Signal, Verdict } from "./types";

const BASE = 48;

export function judge(evidence: Evidence): { score: number; verdict: Verdict; signals: Signal[] } {
  const signals: Signal[] = [];
  const named = evidence.generators.length > 0 || evidence.sdParameters || evidence.generativeFill;
  const camera = isKnownCameraMake(evidence.cameraMake);
  const spoofRisk = Boolean(evidence.pixel && looksSmoothSynthetic(evidence.pixel) && camera);

  for (let index = 0; index < evidence.generators.length; index++) {
    const hit = evidence.generators[index];
    if (!hit) continue;
    signals.push({
      id: `gen-${hit.label}`,
      title: `${hit.label} tag`,
      detail: hit.snippet
        ? `The file contains “${hit.snippet}”. Generators often leave this in the image or clip.`
        : `A ${hit.label} marker is embedded in the file.`,
      weight: index === 0 ? 42 : 0,
      strength: index === 0 ? "strong" : "moderate",
    });
  }

  if (evidence.sdParameters) {
    const already = evidence.generators.some((g) => g.label === "Stable Diffusion");
    signals.push({
      id: "sd-params",
      title: "Stable Diffusion parameters",
      detail: "A prompt block with steps, sampler, and CFG scale is embedded. That is a generation log, not a camera.",
      weight: already ? 0 : 42,
      strength: "strong",
    });
  }

  if (evidence.generativeFill) {
    signals.push({
      id: "gen-fill",
      title: "Generative edit",
      detail: "The file mentions generative fill or expand. At least part of this picture was synthesized.",
      weight: 34,
      strength: "strong",
    });
  }

  if (evidence.c2pa === "trained") {
    signals.push({
      id: "c2pa-trained",
      title: "Content Credentials: trained model",
      detail: "A C2PA manifest says this media came from a trained algorithmic model.",
      weight: 36,
      strength: "strong",
    });
  } else if (evidence.c2pa === "capture") {
    signals.push({
      id: "c2pa-capture",
      title: "Content Credentials: camera capture",
      detail: "A C2PA manifest labels the source as a digital capture rather than a generative model.",
      weight: -18,
      strength: "moderate",
    });
  } else if (evidence.c2pa === "present") {
    signals.push({
      id: "c2pa",
      title: "Content Credentials present",
      detail: "A provenance manifest is attached, but it does not clearly say camera or model.",
      weight: 0,
      strength: "hint",
    });
  }

  if (camera) {
    const who = [evidence.cameraMake, evidence.cameraModel].filter(Boolean).join(" ");
    signals.push({
      id: "camera",
      title: spoofRisk ? "Camera tag, texture disagrees" : "Camera make and model",
      detail: spoofRisk
        ? `${who} is written in the file, but the texture is unusually smooth. Metadata can be copied onto a generated image.`
        : `${who} is a known camera or phone. Generated files rarely keep a real device tag unless someone forged it.`,
      weight: spoofRisk ? -12 : -30,
      strength: spoofRisk ? "moderate" : "strong",
    });
  } else if (evidence.cameraMake || evidence.cameraModel) {
    signals.push({
      id: "device-unknown",
      title: "Device tag",
      detail: `${[evidence.cameraMake, evidence.cameraModel].filter(Boolean).join(" ")} is present, but it is not a recognized camera maker.`,
      weight: -6,
      strength: "hint",
    });
  }

  if (evidence.exposure && camera && !spoofRisk) {
    signals.push({
      id: "exposure",
      title: "Exposure recorded",
      detail: evidence.exposure,
      weight: -8,
      strength: "moderate",
    });
  }

  if (evidence.lens && camera) {
    signals.push({
      id: "lens",
      title: "Lens recorded",
      detail: evidence.lens,
      weight: -4,
      strength: "hint",
    });
  }

  if (evidence.hasGps && camera && !spoofRisk) {
    signals.push({
      id: "gps",
      title: "Location metadata",
      detail: "A location tag is present. The coordinates are not shown.",
      weight: -4,
      strength: "hint",
    });
  }

  if (evidence.editor && !named) {
    signals.push({
      id: "editor",
      title: `Opened in ${evidence.editor}`,
      detail: "An editor tag means the file was processed. That is not the same as being generated.",
      weight: 3,
      strength: "hint",
    });
  }

  if (evidence.software && !named) {
    const soft = evidence.software.toLowerCase();
    const already = signals.some((s) => s.detail.toLowerCase().includes(soft.slice(0, 18)));
    if (!already && evidence.software.length > 1) {
      signals.push({
        id: "software",
        title: "Software tag",
        detail: evidence.software,
        weight: 0,
        strength: "hint",
      });
    }
  }

  if (evidence.syntheticSize && !camera && !named) {
    signals.push({
      id: "canvas",
      title: "Common generator size",
      detail: "The pixel size matches a canvas that image models use often. Phone photos are usually a different size. This alone is not proof.",
      weight: 6,
      strength: "hint",
    });
  }

  if (evidence.pixel && !evidence.decodeFailed) {
    pushPixel(signals, evidence.pixel, named, camera);
  }

  if (evidence.kind === "video" && evidence.framesSampled) {
    signals.push({
      id: "frames",
      title: "Frames sampled",
      detail: `${evidence.framesSampled} frames were checked. Video generators are not settled by one still.`,
      weight: 0,
      strength: "hint",
    });
    if ((evidence.frameSpread ?? 0) > 18) {
      signals.push({
        id: "spread",
        title: "Frames disagree",
        detail: "Some frames look smoother than others. Mixed or re-encoded clips do this.",
        weight: 4,
        strength: "hint",
      });
    }
  }

  if (evidence.decodeFailed) {
    signals.push({
      id: "decode",
      title: "Preview could not be decoded",
      detail: "The browser could not draw this file. The score uses embedded text and metadata only.",
      weight: 0,
      strength: "hint",
    });
  }

  if (signals.every((s) => s.weight === 0)) {
    signals.unshift({
      id: "none",
      title: "No decisive tag",
      detail: "Nothing in the file names a camera or a generator. Stripped metadata is common for both chat screenshots and downloaded AI images.",
      weight: 0,
      strength: "hint",
    });
  }

  const listed = signals.reduce((sum, signal) => sum + signal.weight, 0);
  let target = BASE + listed;
  if (named) target = Math.max(target, evidence.generativeFill && evidence.generators.length === 0 && !evidence.sdParameters ? 74 : 88);
  if (evidence.c2pa === "trained") target = Math.max(target, 84);
  if (camera && !named && evidence.c2pa !== "trained" && !spoofRisk) target = Math.min(target, 26);
  target = clamp(target);
  const delta = target - (BASE + listed);
  if (delta !== 0) {
    signals.push({
      id: "adjust",
      title: "Score pinned",
      detail: "Marks are kept between 4 and 96, and a clear generator or camera tag is not left in the middle.",
      weight: delta,
      strength: "moderate",
    });
  }
  return { score: target, verdict: verdictFor(target), signals };
}

function pushPixel(signals: Signal[], pixel: PixelStats, named: boolean, camera: boolean) {
  if (looksSmoothSynthetic(pixel) && !named) {
    signals.push({
      id: "smooth",
      title: "Unusually smooth texture",
      detail: "Flat areas are very clean while a few edges stay sharp. That can be a generator, a beauty filter, or a heavy denoise.",
      weight: camera ? 8 : 8,
      strength: "hint",
    });
  } else if (looksNatural(pixel) && !named) {
    signals.push({
      id: "texture",
      title: "Varied fine texture",
      detail: "Grain changes across the frame in a way camera photos often do. Modern generators can imitate this.",
      weight: -6,
      strength: "hint",
    });
  }
  if (pixel.flatSaturation > 0.55 && pixel.residualStd < 0.03 && !named) {
    signals.push({
      id: "plastic",
      title: "Flat, saturated color",
      detail: "Large areas are smooth and strongly colored. Illustrations and some generated scenes look like this.",
      weight: 5,
      strength: "hint",
    });
  }
}

export function looksSmoothSynthetic(pixel: PixelStats): boolean {
  return pixel.residualStd < 0.018 && pixel.edgeRatio > 0.06 && pixel.midRatio < 0.1;
}

export function looksNatural(pixel: PixelStats): boolean {
  return pixel.residualStd > 0.035 && pixel.blockCv > 0.4 && pixel.midRatio > 0.12;
}

export function verdictFor(score: number): Verdict {
  if (score >= 67) return "likely_ai";
  if (score <= 34) return "likely_real";
  return "inconclusive";
}

function clamp(n: number): number {
  return Math.max(4, Math.min(96, Math.round(n)));
}
