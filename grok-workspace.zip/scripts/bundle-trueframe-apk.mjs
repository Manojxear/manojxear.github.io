import * as esbuild from "esbuild";
import { spawnSync } from "node:child_process";
import { cp, mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { existsSync } from "node:fs";

const www = process.argv[2];
if (!www) {
  console.error("usage: bundle-trueframe-apk.mjs <outdir>");
  process.exit(1);
}

const root = "/workspace";
await mkdir(www, { recursive: true });

await esbuild.build({
  absWorkingDir: root,
  entryPoints: ["src/apk/main.tsx"],
  bundle: true,
  format: "iife",
  outfile: path.join(www, "app.js"),
  minify: true,
  target: "es2020",
  jsx: "automatic",
  define: { "process.env.NODE_ENV": '"production"' },
  plugins: [
    {
      name: "at-alias",
      setup(build) {
        build.onResolve({ filter: /^@\// }, (args) => {
          const base = path.join(root, "src", args.path.slice(2));
          const candidates = [".ts", ".tsx", ".js", ".mjs"].map((ext) => base + ext);
          const hit = candidates.find((file) => existsSync(file));
          if (!hit) return { path: base, external: false };
          return { path: hit };
        });
      },
    },
  ],
});

const cli = path.join(root, "node_modules/@tailwindcss/cli/dist/index.mjs");
const cssOut = path.join(www, "app.css");
if (!existsSync(cli)) {
  console.error("missing @tailwindcss/cli");
  process.exit(1);
}
const built = spawnSync(process.execPath, [cli, "-i", "src/styles.css", "-o", cssOut], {
  cwd: root,
  stdio: "inherit",
});
if (built.status !== 0) process.exit(built.status ?? 1);

let css = await readFile(cssOut, "utf8");
css = css.replaceAll('url("/fonts/', 'url("./fonts/').replaceAll("url('/fonts/", "url('./fonts/");
await writeFile(cssOut, css);
await mkdir(path.join(www, "fonts"), { recursive: true });
await cp(path.join(root, "public/fonts/fraunces.ttf"), path.join(www, "fonts/fraunces.ttf"));
await cp(path.join(root, "public/fonts/outfit.ttf"), path.join(www, "fonts/outfit.ttf"));
await cp(path.join(root, "android/www/index.html"), path.join(www, "index.html"));

const js = await readFile(path.join(www, "app.js"), "utf8");
if (js.includes("XAI_API_KEY") || js.includes("api.x.ai")) {
  console.error("APK bundle unexpectedly includes the server AI client");
  process.exit(1);
}
console.log("bundled", www);
