#!/bin/sh
set -eu
cd /workspace

SDK=/tmp/android-sdk
BT="$SDK/build-tools/34.0.0"
PLATFORM="$SDK/platforms/android-34/android.jar"
OUT=/tmp/trueframe-apk
WWW=/tmp/trueframe-www

if [ ! -x "$BT/aapt2" ]; then
  echo "Android build-tools missing" >&2
  exit 1
fi

node scripts/bundle-trueframe-apk.mjs "$WWW"

rm -rf "$OUT"
mkdir -p "$OUT/classes" "$OUT/res"

node scripts/write-launcher-icon.mjs "$OUT/ic_launcher.png"
cp "$OUT/ic_launcher.png" /tmp/ic_launcher.png
mkdir -p /tmp/tf-res/drawable
cp "$OUT/ic_launcher.png" /tmp/tf-res/drawable/ic_launcher.png

export JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-17-openjdk-amd64}"
javac --release 11 -classpath "$PLATFORM" -d "$OUT/classes" \
  android/app/src/main/java/com/nethamanoj/trueframe/MainActivity.java

"$BT/d8" --lib "$PLATFORM" --output "$OUT" $(find "$OUT/classes" -name '*.class')

"$BT/aapt2" compile --dir /tmp/tf-res -o "$OUT/res.zip"
"$BT/aapt2" link \
  -o "$OUT/base.apk" \
  -I "$PLATFORM" \
  --manifest android/app/src/main/AndroidManifest.xml \
  --min-sdk-version 24 \
  --target-sdk-version 34 \
  --version-code 1 \
  --version-name 1.0.0 \
  -A "$WWW" \
  "$OUT/res.zip"

cp "$OUT/base.apk" "$OUT/unaligned.apk"
python3 - "$OUT/unaligned.apk" "$OUT/classes.dex" <<'PY'
import sys, zipfile
apk, dex = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(apk, "a") as z:
    z.write(dex, "classes.dex", compress_type=zipfile.ZIP_STORED)
PY
"$BT/zipalign" -f 4 "$OUT/unaligned.apk" "$OUT/aligned.apk"

if [ ! -f "$OUT/debug.keystore" ]; then
  keytool -genkeypair -v \
    -keystore "$OUT/debug.keystore" \
    -storepass android -keypass android \
    -alias trueframe -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=NETHA MANOJ, O=TrueFrame, C=IN"
fi

"$BT/apksigner" sign \
  --ks "$OUT/debug.keystore" \
  --ks-pass pass:android \
  --key-pass pass:android \
  --ks-key-alias trueframe \
  --out /workspace/public/trueframe.apk \
  "$OUT/aligned.apk"

"$BT/apksigner" verify /workspace/public/trueframe.apk
mkdir -p /workspace/artifacts
cp /workspace/public/trueframe.apk /workspace/artifacts/TrueFrame.apk
ls -lh /workspace/public/trueframe.apk
echo APK_OK
