import { deflateSync } from "node:zlib";
import { writeFileSync } from "node:fs";

const size = 192;
const out = process.argv[2] || "/tmp/ic_launcher.png";
const raw = Buffer.alloc((size * 4 + 1) * size);
const ink = [0x1c, 0x19, 0x15];
const brass = [0x8d, 0x5e, 0x32];
const paper = [0xf4, 0xef, 0xe6];
const cx = (size - 1) / 2;
const cy = (size - 1) / 2;

for (let y = 0; y < size; y++) {
  const row = y * (size * 4 + 1);
  raw[row] = 0;
  for (let x = 0; x < size; x++) {
    const dx = x - cx;
    const dy = y - cy;
    const d = Math.hypot(dx, dy);
    let rgb = ink;
    if (d < 78 && d > 62) rgb = brass;
    else if (d < 46 && d > 34) rgb = paper;
    else if (d < 8) rgb = brass;
    const i = row + 1 + x * 4;
    raw[i] = rgb[0];
    raw[i + 1] = rgb[1];
    raw[i + 2] = rgb[2];
    raw[i + 3] = 255;
  }
}

function chunk(type, data) {
  const body = Buffer.concat([Buffer.from(type), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body) >>> 0);
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  return Buffer.concat([len, body, crc]);
}

let ctable;
function crc32(buf) {
  if (!ctable) {
    ctable = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      ctable[n] = c >>> 0;
    }
  }
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = ctable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

const ihdr = Buffer.alloc(13);
ihdr.writeUInt32BE(size, 0);
ihdr.writeUInt32BE(size, 4);
ihdr[8] = 8;
ihdr[9] = 6;
const png = Buffer.concat([
  Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
  chunk("IHDR", ihdr),
  chunk("IDAT", deflateSync(raw)),
  chunk("IEND", Buffer.alloc(0)),
]);
writeFileSync(out, png);
