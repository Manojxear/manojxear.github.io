import { evidenceFromContainer, inspectFile } from "../src/lib/forensics/metadata";
import { judge } from "../src/lib/forensics/judge";

function assert(cond: unknown, message: string) {
  if (!cond) throw new Error(message);
}

function jpegWithComment(text: string): Uint8Array {
  const body = new TextEncoder().encode(text);
  const size = 2 + body.length;
  const out = new Uint8Array(2 + 2 + 2 + body.length + 2);
  out[0] = 0xff;
  out[1] = 0xd8;
  out[2] = 0xff;
  out[3] = 0xfe;
  out[4] = (size >> 8) & 0xff;
  out[5] = size & 0xff;
  out.set(body, 6);
  out[out.length - 2] = 0xff;
  out[out.length - 1] = 0xd9;
  return out;
}

function appleExifJpeg(): Uint8Array {
  const make = "Apple";
  const model = "iPhone";
  const tiff = new Uint8Array(64);
  tiff[0] = 0x49;
  tiff[1] = 0x49;
  tiff[2] = 42;
  tiff[4] = 8;
  tiff[8] = 2;
  writeEntry(tiff, 10, 271, 38, make.length + 1);
  writeEntry(tiff, 22, 272, 48, model.length + 1);
  writeAscii(tiff, 38, make);
  writeAscii(tiff, 48, model);
  const header = new TextEncoder().encode("Exif\0\0");
  const payload = new Uint8Array(header.length + tiff.length);
  payload.set(header, 0);
  payload.set(tiff, header.length);
  const size = 2 + payload.length;
  const out = new Uint8Array(4 + 2 + payload.length + 2);
  out[0] = 0xff;
  out[1] = 0xd8;
  out[2] = 0xff;
  out[3] = 0xe1;
  out[4] = (size >> 8) & 0xff;
  out[5] = size & 0xff;
  out.set(payload, 6);
  out[out.length - 2] = 0xff;
  out[out.length - 1] = 0xd9;
  return out;
}

function writeEntry(buf: Uint8Array, at: number, tag: number, offset: number, count: number) {
  buf[at] = tag & 0xff;
  buf[at + 1] = (tag >> 8) & 0xff;
  buf[at + 2] = 2;
  buf[at + 4] = count & 0xff;
  buf[at + 8] = offset & 0xff;
  buf[at + 9] = (offset >> 8) & 0xff;
}

function writeAscii(buf: Uint8Array, at: number, text: string) {
  for (let i = 0; i < text.length; i++) buf[at + i] = text.charCodeAt(i);
}

const generated = evidenceFromContainer("image", inspectFile(jpegWithComment("Made with Midjourney v6"), new Uint8Array()));
const genJudge = judge(generated);
assert(genJudge.verdict === "likely_ai", `midjourney verdict ${genJudge.verdict} ${genJudge.score}`);
assert(genJudge.score >= 80, `midjourney score ${genJudge.score}`);

const cameraInfo = inspectFile(appleExifJpeg(), new Uint8Array());
assert(cameraInfo.make === "Apple", `make was ${cameraInfo.make}`);
assert(cameraInfo.model === "iPhone", `model was ${cameraInfo.model}`);
const camera = judge(evidenceFromContainer("image", cameraInfo));
assert(camera.verdict === "likely_real", `camera verdict ${camera.verdict} ${camera.score}`);
assert(camera.score <= 34, `camera score ${camera.score}`);

const plain = judge(evidenceFromContainer("image", inspectFile(jpegWithComment("holiday"), new Uint8Array())));
assert(plain.verdict === "inconclusive", `plain verdict ${plain.verdict} ${plain.score}`);

const sum = (base: number, weights: number[]) => base + weights.reduce((a, b) => a + b, 0);
assert(sum(48, genJudge.signals.map((s) => s.weight)) === genJudge.score, "generator weights must sum to score");
assert(sum(48, camera.signals.map((s) => s.weight)) === camera.score, "camera weights must sum to score");

console.log("forensics ok", {
  generated: genJudge.score,
  camera: camera.score,
  plain: plain.score,
  make: cameraInfo.make,
  model: cameraInfo.model,
});
