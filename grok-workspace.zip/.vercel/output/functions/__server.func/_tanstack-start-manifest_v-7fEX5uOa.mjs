//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-7fEX5uOa.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D3CMOE9n.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D3CMOE9n.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BAZnRBD-.js"]
	}
} });
//#endregion
export { tsrStartManifest };
