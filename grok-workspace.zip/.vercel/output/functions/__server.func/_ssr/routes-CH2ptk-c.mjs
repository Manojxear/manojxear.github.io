import { i as __toESM } from "../_runtime.mjs";
import { U as isRedirect, b as require_jsx_runtime, q as require_react, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Download, i as History, n as TriangleAlert, o as Clapperboard, r as Image, s as Aperture, t as Upload } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CH2ptk-c.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
/** Case-insensitive ASCII search. Returns -1 when absent. */
function indexOfAscii(hay, needle, from = 0, to = hay.length) {
	const n = needle.length;
	if (n === 0) return -1;
	const end = Math.min(hay.length, to) - n;
	const codes = new Uint8Array(n);
	for (let j = 0; j < n; j++) codes[j] = fold(needle.charCodeAt(j));
	outer: for (let i = from; i <= end; i++) {
		for (let j = 0; j < n; j++) if (fold(hay[i + j] ?? 0) !== codes[j]) continue outer;
		return i;
	}
	return -1;
}
function fold(c) {
	return c >= 65 && c <= 90 ? c + 32 : c;
}
function snippetAround(hay, at, needleLen) {
	const start = Math.max(0, at - 28);
	const end = Math.min(hay.length, at + needleLen + 36);
	let s = "";
	for (let i = start; i < end; i++) {
		const c = hay[i] ?? 0;
		s += c >= 32 && c < 127 ? String.fromCharCode(c) : " ";
	}
	return s.replace(/\s+/g, " ").trim().slice(0, 96);
}
function asciiSlice(hay, offset, count) {
	let s = "";
	const end = Math.min(hay.length, offset + count);
	for (let i = offset; i < end; i++) {
		const c = hay[i] ?? 0;
		if (c === 0) break;
		s += c >= 32 && c < 127 ? String.fromCharCode(c) : " ";
	}
	return s.trim();
}
/** Longer phrases only. Short words false-match compressed bytes. */
var GENERATORS = [
	{
		label: "Midjourney",
		needles: ["midjourney"]
	},
	{
		label: "Stable Diffusion",
		needles: [
			"stable diffusion",
			"stablediffusion",
			"novelai",
			"comfyui",
			"automatic1111",
			"invokeai",
			"fooocus",
			"tensor.art",
			"civitai"
		]
	},
	{
		label: "DALL·E",
		needles: [
			"dall-e",
			"dalle-2",
			"dalle-3",
			"dall·e"
		]
	},
	{
		label: "ChatGPT image",
		needles: ["gpt-image", "chatgpt image"]
	},
	{
		label: "Adobe Firefly",
		needles: ["adobe firefly", "firefly"]
	},
	{
		label: "Ideogram",
		needles: ["ideogram"]
	},
	{
		label: "Leonardo",
		needles: ["leonardo.ai", "leonardo ai"]
	},
	{
		label: "Flux",
		needles: ["flux.1", "black forest labs"]
	},
	{
		label: "Google Imagen",
		needles: [
			"imagen 3",
			"imagen-3",
			"imagen 4",
			"imagen-4"
		]
	},
	{
		label: "Grok image",
		needles: ["grok-imagine", "grok image"]
	},
	{
		label: "Runway",
		needles: [
			"runwayml",
			"runway gen",
			"gen-3 alpha"
		]
	},
	{
		label: "Kling",
		needles: ["kling ai", "klingai"]
	},
	{
		label: "Pika",
		needles: ["pika.art", "pika labs"]
	},
	{
		label: "Luma",
		needles: ["lumalabs", "luma dream machine"]
	},
	{
		label: "OpenAI Sora",
		needles: ["openai sora"]
	},
	{
		label: "Google Veo",
		needles: [
			"google veo",
			"veo-2",
			"veo-3"
		]
	},
	{
		label: "Haiper",
		needles: ["haiper.ai"]
	},
	{
		label: "Synthesia",
		needles: ["synthesia"]
	},
	{
		label: "HeyGen",
		needles: ["heygen"]
	},
	{
		label: "Dreamina",
		needles: ["dreamina"]
	},
	{
		label: "Recraft",
		needles: ["recraft.ai"]
	},
	{
		label: "NightCafe",
		needles: ["nightcafe"]
	},
	{
		label: "SeaArt",
		needles: ["seaart.ai"]
	},
	{
		label: "Microsoft Designer",
		needles: ["microsoft designer", "bing image creator"]
	},
	{
		label: "Meta AI",
		needles: ["make-a-video", "meta ai imagine"]
	}
];
var GENERATIVE_EDIT_NEEDLES = ["generative fill", "generative expand"];
var EDITORS = [
	{
		label: "Photoshop",
		needles: ["adobe photoshop"]
	},
	{
		label: "Lightroom",
		needles: ["adobe photoshop lightroom", "lightroom"]
	},
	{
		label: "Snapseed",
		needles: ["snapseed"]
	},
	{
		label: "GIMP",
		needles: ["gimp"]
	},
	{
		label: "Capture One",
		needles: ["capture one"]
	},
	{
		label: "Affinity Photo",
		needles: ["affinity photo"]
	},
	{
		label: "VSCO",
		needles: ["vsco"]
	}
];
var CAMERA_MAKES = [
	"apple",
	"canon",
	"nikon",
	"sony",
	"fujifilm",
	"fuji photo film",
	"olympus",
	"om digital",
	"panasonic",
	"leica",
	"hasselblad",
	"phase one",
	"ricoh",
	"pentax",
	"gopro",
	"dji",
	"samsung",
	"google",
	"motorola",
	"huawei",
	"xiaomi",
	"oneplus",
	"oppo",
	"vivo",
	"honor",
	"tcl",
	"kodak",
	"casio",
	"sigma",
	"hmd global",
	"lge",
	"lg electronics",
	"blackmagic",
	"zeiss",
	"nokia"
];
/** Common generator canvases. Phone screenshots are intentionally absent. */
var AI_LONG = /* @__PURE__ */ new Set([
	512,
	576,
	640,
	704,
	768,
	832,
	896,
	960,
	1024,
	1088,
	1152,
	1216,
	1280,
	1344,
	1408,
	1472,
	1536,
	1600,
	1664,
	1728,
	1792,
	1920,
	2048,
	2304,
	2560
]);
var AI_PAIRS = [
	[832, 1216],
	[896, 1152],
	[768, 1344],
	[640, 1536],
	[1024, 1536],
	[1024, 1792],
	[1024, 1360],
	[768, 1024],
	[512, 768],
	[720, 1280],
	[1280, 720]
];
function isSyntheticCanvas(width, height) {
	if (!width || !height) return false;
	const a = Math.min(width, height);
	const b = Math.max(width, height);
	if (width === height && AI_LONG.has(width)) return true;
	return AI_PAIRS.some(([w, h]) => a === Math.min(w, h) && b === Math.max(w, h));
}
function isKnownCameraMake(make) {
	if (!make) return false;
	const m = make.trim().toLowerCase();
	return CAMERA_MAKES.some((c) => m === c || m.startsWith(`${c} `) || m.includes(c));
}
var EMPTY = {
	format: "Unknown",
	texts: [],
	hasGps: false,
	parameterChunk: false
};
function inspectFile(head, tail) {
	try {
		if (isJpeg(head)) return inspectJpeg(head);
		if (isPng(head)) return inspectPng(head);
		if (isWebp(head)) return inspectWebp(head);
		if (isGif(head)) return {
			...EMPTY,
			format: "GIF",
			texts: collectTexts(head, tail)
		};
		if (isWebm(head)) return {
			...EMPTY,
			format: "WebM",
			texts: collectTexts(head, tail)
		};
		if (isIsoBmff(head) || isIsoBmff(tail)) return {
			...EMPTY,
			format: isoBrand(head) ?? isoBrand(tail) ?? "MP4",
			texts: collectTexts(head, tail)
		};
		return {
			...EMPTY,
			format: "File",
			texts: collectTexts(head, tail)
		};
	} catch {
		return {
			...EMPTY,
			format: "File",
			texts: collectTexts(head, tail)
		};
	}
}
function evidenceFromContainer(kind, info, extraText = []) {
	const corpus = [
		info.software,
		info.make,
		info.model,
		info.lens,
		...info.texts,
		...extraText
	].filter((t) => Boolean(t && t.trim()));
	const generators = findGenerators(corpus);
	const generativeFill = corpus.some((t) => GENERATIVE_EDIT_NEEDLES.some((n) => t.toLowerCase().includes(n)));
	const sdParameters = info.parameterChunk || corpus.some((t) => {
		const s = t.toLowerCase();
		return s.includes("steps:") && s.includes("sampler:") && (s.includes("cfg scale") || s.includes("cfg:"));
	});
	const c2pa = c2paKind(corpus);
	const editor = findEditor(corpus);
	const make = clean(info.make);
	const model = clean(info.model);
	return {
		kind,
		generators,
		sdParameters,
		generativeFill,
		c2pa,
		cameraMake: isKnownCameraMake(make) ? make : make || void 0,
		cameraModel: model,
		software: clean(info.software),
		lens: clean(info.lens),
		exposure: info.exposure,
		taken: info.taken,
		hasGps: info.hasGps,
		editor,
		syntheticSize: isSyntheticCanvas(info.width ?? 0, info.height ?? 0)
	};
}
function findGenerators(texts) {
	const hits = [];
	const seen = /* @__PURE__ */ new Set();
	for (const pattern of GENERATORS) {
		const hit = matchPattern(texts, pattern);
		if (hit && !seen.has(hit.label)) {
			seen.add(hit.label);
			hits.push(hit);
		}
	}
	return hits;
}
function matchPattern(texts, pattern) {
	for (const text of texts) {
		const lower = text.toLowerCase();
		for (const needle of pattern.needles) {
			const at = lower.indexOf(needle);
			if (at >= 0) {
				const raw = text.slice(Math.max(0, at - 24), at + needle.length + 32);
				return {
					label: pattern.label,
					snippet: raw.replace(/\s+/g, " ").trim().slice(0, 96)
				};
			}
		}
	}
}
function findEditor(texts) {
	const blob = texts.join("\n").toLowerCase();
	for (const editor of EDITORS) if (editor.needles.some((n) => blob.includes(n))) return editor.label;
}
function c2paKind(texts) {
	const blob = texts.join("\n").toLowerCase();
	if (blob.includes("trainedalgorithmicmedia") || blob.includes("compositesynthetic")) return "trained";
	if (blob.includes("digitalcapture")) return "capture";
	if (blob.includes("c2pa") || blob.includes("contentcredentials") || blob.includes("jumbf")) return "present";
	return "none";
}
function collectTexts(head, tail) {
	return [latinWindow(head), latinWindow(tail)].filter((s) => s.length > 0);
}
function latinWindow(bytes) {
	let s = "";
	for (let i = 0; i < bytes.length; i++) {
		const c = bytes[i] ?? 0;
		s += c >= 32 && c < 127 ? String.fromCharCode(c) : "\n";
	}
	return s;
}
function clean(value) {
	const v = value?.replace(/\s+/g, " ").trim();
	return v ? v.slice(0, 120) : void 0;
}
function isJpeg(b) {
	return b.length > 3 && b[0] === 255 && b[1] === 216 && b[2] === 255;
}
function isPng(b) {
	return b.length > 8 && b[0] === 137 && b[1] === 80 && b[2] === 78 && b[3] === 71;
}
function isGif(b) {
	return indexOfAscii(b, "GIF8", 0, 6) === 0;
}
function isWebp(b) {
	return indexOfAscii(b, "RIFF", 0, 4) === 0 && indexOfAscii(b, "WEBP", 8, 12) === 8;
}
function isWebm(b) {
	return b.length > 4 && b[0] === 26 && b[1] === 69 && b[2] === 223 && b[3] === 163;
}
function isIsoBmff(b) {
	return indexOfAscii(b, "ftyp", 4, 12) === 4;
}
function isoBrand(b) {
	if (!isIsoBmff(b)) return void 0;
	const brand = asciiSlice(b, 8, 4).toLowerCase();
	if (brand.startsWith("qt")) return "MOV";
	if (brand.includes("web")) return "WebM";
	return "MP4";
}
function inspectJpeg(bytes) {
	const info = {
		format: "JPEG",
		texts: [],
		hasGps: false,
		parameterChunk: false
	};
	let o = 2;
	while (o + 4 < bytes.length) {
		if (bytes[o] !== 255) {
			o += 1;
			continue;
		}
		const marker = bytes[o + 1] ?? 0;
		if (marker === 217 || marker === 218) break;
		if (marker === 0 || marker === 1 || marker >= 208 && marker <= 216) {
			o += 2;
			continue;
		}
		if (o + 4 > bytes.length) break;
		const size = (bytes[o + 2] ?? 0) << 8 | (bytes[o + 3] ?? 0);
		if (size < 2 || o + 2 + size > bytes.length) break;
		const start = o + 4;
		const end = o + 2 + size;
		if (marker === 254) info.texts.push(asciiSlice(bytes, start, end - start));
		if (marker >= 224 && marker <= 239) absorbApp(info, bytes, start, end);
		if (marker >= 192 && marker <= 195 || marker >= 197 && marker <= 199 || marker >= 201 && marker <= 203) {
			if (end - start >= 6) {
				info.height = (bytes[start + 1] ?? 0) << 8 | (bytes[start + 2] ?? 0);
				info.width = (bytes[start + 3] ?? 0) << 8 | (bytes[start + 4] ?? 0);
			}
		}
		o = end;
	}
	info.texts.push(latinWindow(bytes.subarray(0, Math.min(bytes.length, 196608))));
	return info;
}
function absorbApp(info, bytes, start, end) {
	if (indexOfAscii(bytes, "Exif", start, start + 6) === start) {
		readExif(info, bytes, start + 6);
		return;
	}
	if (indexOfAscii(bytes, "http://ns.adobe.com/xap", start, start + 32) === start) {
		const zero = bytes.indexOf(0, start);
		const textStart = zero > start && zero < end ? zero + 1 : start;
		info.texts.push(asciiSlice(bytes, textStart, end - textStart));
		return;
	}
	info.texts.push(asciiSlice(bytes, start, Math.min(4e3, end - start)));
}
function inspectPng(bytes) {
	const info = {
		format: "PNG",
		texts: [],
		hasGps: false,
		parameterChunk: false
	};
	let o = 8;
	while (o + 12 <= bytes.length) {
		const length = readU32(bytes, o);
		const type = asciiSlice(bytes, o + 4, 4);
		const data = o + 8;
		if (length < 0 || data + length + 4 > bytes.length) break;
		if (type === "IHDR" && length >= 8) {
			info.width = readU32(bytes, data);
			info.height = readU32(bytes, data + 4);
		} else if (type === "tEXt" || type === "iTXt") {
			const text = latinLen(bytes, data, length);
			info.texts.push(text);
			if (/^parameters\b/i.test(text)) info.parameterChunk = true;
		} else if (type === "zTXt") {
			const key = asciiSlice(bytes, data, length);
			info.texts.push(key);
			if (/^parameters$/i.test(key)) info.parameterChunk = true;
		} else if (type === "eXIf") readExif(info, bytes, data);
		else if (type === "tIME" || type === "caBX" || type.startsWith("ca")) info.texts.push(asciiSlice(bytes, data, Math.min(length, 8e3)));
		o = data + length + 4;
	}
	return info;
}
function latinLen(bytes, offset, count) {
	let s = "";
	const end = Math.min(bytes.length, offset + count);
	for (let i = offset; i < end; i++) {
		const c = bytes[i] ?? 0;
		s += c >= 32 && c < 127 ? String.fromCharCode(c) : " ";
	}
	return s.replace(/\s+/g, " ").trim();
}
function inspectWebp(bytes) {
	const info = {
		format: "WebP",
		texts: [latinWindow(bytes.subarray(0, Math.min(bytes.length, 196608)))],
		hasGps: false,
		parameterChunk: false
	};
	let o = 12;
	while (o + 8 <= bytes.length) {
		const type = asciiSlice(bytes, o, 4);
		const size = readU32le(bytes, o + 4);
		const data = o + 8;
		if (size < 0 || data + size > bytes.length + 1) break;
		if (type === "EXIF") {
			if (indexOfAscii(bytes, "Exif", data, data + 6) === data) readExif(info, bytes, data + 6);
			else readExif(info, bytes, data);
		}
		if (type === "XMP " || type === "XMP") info.texts.push(latinLen(bytes, data, Math.min(size, 8e3)));
		o = data + (size + size % 2);
	}
	return info;
}
function readU32(bytes, o) {
	return ((bytes[o] ?? 0) << 24 | (bytes[o + 1] ?? 0) << 16 | (bytes[o + 2] ?? 0) << 8 | (bytes[o + 3] ?? 0)) >>> 0;
}
function readU32le(bytes, o) {
	return ((bytes[o] ?? 0) | (bytes[o + 1] ?? 0) << 8 | (bytes[o + 2] ?? 0) << 16 | (bytes[o + 3] ?? 0) << 24) >>> 0;
}
function readExif(info, bytes, tiff) {
	if (tiff + 8 > bytes.length) return;
	const le = bytes[tiff] === 73 && bytes[tiff + 1] === 73;
	const be = bytes[tiff] === 77 && bytes[tiff + 1] === 77;
	if (!le && !be) return;
	const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
	if (view.getUint16(tiff + 2, le) !== 42) return;
	walkIfd(info, view, tiff, view.getUint32(tiff + 4, le), le, 0);
}
function walkIfd(info, view, tiff, ifdOffset, le, depth) {
	if (depth > 4) return;
	const abs = tiff + ifdOffset;
	if (abs < 0 || abs + 2 > view.byteLength) return;
	let count = 0;
	try {
		count = view.getUint16(abs, le);
	} catch {
		return;
	}
	if (count > 256) return;
	for (let i = 0; i < count; i++) {
		const e = abs + 2 + i * 12;
		if (e + 12 > view.byteLength) return;
		const tag = view.getUint16(e, le);
		const type = view.getUint16(e + 2, le);
		const n = view.getUint32(e + 4, le);
		applyTag(info, tag, readTag(view, tiff, e + 8, type, n, le), view, tiff, le, depth);
	}
}
function applyTag(info, tag, value, view, tiff, le, depth) {
	if (tag === 271 && value) info.make = value;
	else if (tag === 272 && value) info.model = value;
	else if (tag === 305 && value) info.software = value;
	else if (tag === 306 && value && !info.taken) info.taken = value;
	else if (tag === 36867 && value) info.taken = value;
	else if (tag === 42036 && value) info.lens = value;
	else if (tag === 270 && value) info.texts.push(value);
	else if (tag === 315 && value) info.texts.push(value);
	else if (tag === 33432 && value) info.texts.push(value);
	else if (tag === 37510 && value) info.texts.push(value);
	else if ((tag === 34665 || tag === 34853 || tag === 40965) && value && /^\d+$/.test(value)) {
		if (tag === 34853) info.hasGps = true;
		else walkIfd(info, view, tiff, Number(value), le, depth + 1);
	} else if (tag === 33437 || tag === 33434 || tag === 34855 || tag === 37386) {
		const piece = formatExposurePiece(tag, value);
		if (piece) info.exposure = info.exposure ? `${info.exposure} · ${piece}` : piece;
	}
}
function formatExposurePiece(tag, value) {
	if (!value) return void 0;
	if (tag === 33437) return `f/${trimNum(value)}`;
	if (tag === 37386) return `${trimNum(value)}mm`;
	if (tag === 34855) return `ISO ${value}`;
	if (tag === 33434) {
		const n = Number(value);
		if (!Number.isFinite(n) || n <= 0) return void 0;
		if (n >= 1) return `${trimNum(String(n))}s`;
		return `1/${Math.round(1 / n)}s`;
	}
}
function trimNum(value) {
	const n = Number(value);
	if (!Number.isFinite(n)) return value;
	return String(Math.round(n * 100) / 100);
}
function readTag(view, tiff, valueField, type, count, le) {
	const unit = typeSize(type);
	if (!unit || count <= 0 || count > 8e6) return void 0;
	const bytes = unit * count;
	let pos = valueField;
	if (bytes > 4) pos = tiff + view.getUint32(valueField, le);
	if (pos < 0 || pos + Math.min(bytes, 4) > view.byteLength) return void 0;
	if (type === 2) {
		const n = Math.min(count, 400);
		if (pos + n > view.byteLength) return void 0;
		let s = "";
		for (let i = 0; i < n; i++) {
			const c = view.getUint8(pos + i);
			if (c === 0) break;
			s += c >= 32 && c < 127 ? String.fromCharCode(c) : " ";
		}
		return s.trim();
	}
	if (type === 3 && count >= 1) return String(view.getUint16(pos, le));
	if (type === 4 && count >= 1) return String(view.getUint32(pos, le));
	if (type === 5 && count >= 1 && pos + 8 <= view.byteLength) {
		const num = view.getUint32(pos, le);
		const den = view.getUint32(pos + 4, le);
		if (!den) return void 0;
		return String(num / den);
	}
	if (type === 10 && count >= 1 && pos + 8 <= view.byteLength) {
		const num = view.getInt32(pos, le);
		const den = view.getInt32(pos + 4, le);
		if (!den) return void 0;
		return String(num / den);
	}
	if ((type === 1 || type === 7) && count < 64) return void 0;
	if (type === 7 && count > 8) {
		const n = Math.min(count, 240);
		if (pos + n > view.byteLength) return void 0;
		return snippetAround(new Uint8Array(view.buffer, view.byteOffset + pos, n), 0, n);
	}
}
function typeSize(type) {
	switch (type) {
		case 1:
		case 2:
		case 6:
		case 7: return 1;
		case 3:
		case 8: return 2;
		case 4:
		case 9:
		case 11: return 4;
		case 5:
		case 10:
		case 12: return 8;
		default: return 0;
	}
}
var MAX_SIDE = 320;
function drawSource(source, width, height) {
	if (!width || !height) return void 0;
	const scale = Math.min(1, MAX_SIDE / Math.max(width, height));
	const w = Math.max(1, Math.round(width * scale));
	const h = Math.max(1, Math.round(height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) return void 0;
	ctx.drawImage(source, 0, 0, w, h);
	const image = ctx.getImageData(0, 0, w, h);
	return {
		stats: statsFromImageData(image),
		residualUrl: residualDataUrl(image)
	};
}
function statsFromImageData(image) {
	const { width: w, height: h, data } = image;
	const n = w * h;
	const gray = new Float32Array(n);
	for (let p = 0, i = 0; p < n; p++, i += 4) gray[p] = ((data[i] ?? 0) * .299 + (data[i + 1] ?? 0) * .587 + (data[i + 2] ?? 0) * .114) / 255;
	const blur = boxBlur(gray, w, h);
	const residual = new Float32Array(n);
	let sum = 0;
	let sumSq = 0;
	let edge = 0;
	let mid = 0;
	let flatSat = 0;
	let flatCount = 0;
	for (let p = 0; p < n; p++) {
		const r = Math.abs((gray[p] ?? 0) - (blur[p] ?? 0));
		residual[p] = r;
		sum += r;
		sumSq += r * r;
	}
	const mean = sum / n;
	const variance = Math.max(0, sumSq / n - mean * mean);
	const std = Math.sqrt(variance);
	for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
		const p = y * w + x;
		const gx = -(gray[p - w - 1] ?? 0) + (gray[p - w + 1] ?? 0) - 2 * (gray[p - 1] ?? 0) + 2 * (gray[p + 1] ?? 0) - (gray[p + w - 1] ?? 0) + (gray[p + w + 1] ?? 0);
		const gy = -(gray[p - w - 1] ?? 0) - 2 * (gray[p - w] ?? 0) - (gray[p - w + 1] ?? 0) + (gray[p + w - 1] ?? 0) + 2 * (gray[p + w] ?? 0) + (gray[p + w + 1] ?? 0);
		if (Math.hypot(gx, gy) > .55) edge += 1;
		const rv = residual[p] ?? 0;
		if (rv > .02 && rv < .08) mid += 1;
		if (rv < .012) {
			const i = p * 4;
			const R = (data[i] ?? 0) / 255;
			const G = (data[i + 1] ?? 0) / 255;
			const B = (data[i + 2] ?? 0) / 255;
			const max = Math.max(R, G, B);
			const min = Math.min(R, G, B);
			if (max > .08) {
				flatSat += (max - min) / max;
				flatCount += 1;
			}
		}
	}
	const inner = Math.max(1, (w - 2) * (h - 2));
	return {
		residualMean: mean,
		residualStd: std,
		blockCv: blockCv(residual, w, h),
		edgeRatio: edge / inner,
		midRatio: mid / inner,
		flatSaturation: flatCount > 40 ? flatSat / flatCount : 0
	};
}
function residualDataUrl(image) {
	const { width: w, height: h, data } = image;
	const canvas = document.createElement("canvas");
	const scale = Math.min(1, 200 / Math.max(w, h));
	canvas.width = Math.max(1, Math.round(w * scale));
	canvas.height = Math.max(1, Math.round(h * scale));
	const ctx = canvas.getContext("2d");
	if (!ctx) return "";
	const out = ctx.createImageData(w, h);
	const gray = new Float32Array(w * h);
	for (let p = 0, i = 0; p < gray.length; p++, i += 4) gray[p] = ((data[i] ?? 0) * .299 + (data[i + 1] ?? 0) * .587 + (data[i + 2] ?? 0) * .114) / 255;
	const blur = boxBlur(gray, w, h);
	for (let p = 0, i = 0; p < gray.length; p++, i += 4) {
		const amp = Math.min(255, Math.abs((gray[p] ?? 0) - (blur[p] ?? 0)) * 1400);
		out.data[i] = 80 + amp * .55;
		out.data[i + 1] = 62 + amp * .28;
		out.data[i + 2] = 42;
		out.data[i + 3] = 255;
	}
	const src = document.createElement("canvas");
	src.width = w;
	src.height = h;
	src.getContext("2d")?.putImageData(out, 0, 0);
	ctx.imageSmoothingEnabled = true;
	ctx.drawImage(src, 0, 0, canvas.width, canvas.height);
	return canvas.toDataURL("image/jpeg", .72);
}
function blockCv(residual, w, h) {
	const size = 16;
	const means = [];
	for (let y = 0; y + size <= h; y += size) for (let x = 0; x + size <= w; x += size) {
		let s = 0;
		for (let yy = 0; yy < size; yy++) {
			const row = (y + yy) * w + x;
			for (let xx = 0; xx < size; xx++) s += residual[row + xx] ?? 0;
		}
		means.push(s / 256);
	}
	if (means.length < 4) return 0;
	const mean = means.reduce((a, b) => a + b, 0) / means.length;
	if (mean < 1e-6) return 0;
	const variance = means.reduce((a, b) => a + (b - mean) ** 2, 0) / means.length;
	return Math.sqrt(variance) / mean;
}
function boxBlur(src, w, h) {
	const tmp = new Float32Array(src.length);
	const dst = new Float32Array(src.length);
	for (let y = 0; y < h; y++) {
		const row = y * w;
		for (let x = 0; x < w; x++) {
			const a = src[row + (x > 0 ? x - 1 : x)] ?? 0;
			const b = src[row + x] ?? 0;
			const c = src[row + (x + 1 < w ? x + 1 : x)] ?? 0;
			tmp[row + x] = (a + b + c) / 3;
		}
	}
	for (let x = 0; x < w; x++) for (let y = 0; y < h; y++) {
		const y0 = y > 0 ? y - 1 : y;
		const y1 = y + 1 < h ? y + 1 : y;
		dst[y * w + x] = ((tmp[y0 * w + x] ?? 0) + (tmp[y * w + x] ?? 0) + (tmp[y1 * w + x] ?? 0)) / 3;
	}
	return dst;
}
async function jpegDataUrl(source, width, height) {
	const scale = Math.min(1, 640 / Math.max(width, height, 1));
	const canvas = document.createElement("canvas");
	canvas.width = Math.max(1, Math.round(width * scale));
	canvas.height = Math.max(1, Math.round(height * scale));
	const ctx = canvas.getContext("2d");
	if (!ctx) return "";
	ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
	return canvas.toDataURL("image/jpeg", .62);
}
var BASE = 48;
function judge(evidence) {
	const signals = [];
	const named = evidence.generators.length > 0 || evidence.sdParameters || evidence.generativeFill;
	const camera = isKnownCameraMake(evidence.cameraMake);
	const spoofRisk = Boolean(evidence.pixel && looksSmoothSynthetic(evidence.pixel) && camera);
	for (let index = 0; index < evidence.generators.length; index++) {
		const hit = evidence.generators[index];
		if (!hit) continue;
		signals.push({
			id: `gen-${hit.label}`,
			title: `${hit.label} tag`,
			detail: hit.snippet ? `The file contains “${hit.snippet}”. Generators often leave this in the image or clip.` : `A ${hit.label} marker is embedded in the file.`,
			weight: index === 0 ? 42 : 0,
			strength: index === 0 ? "strong" : "moderate"
		});
	}
	if (evidence.sdParameters) {
		const already = evidence.generators.some((g) => g.label === "Stable Diffusion");
		signals.push({
			id: "sd-params",
			title: "Stable Diffusion parameters",
			detail: "A prompt block with steps, sampler, and CFG scale is embedded. That is a generation log, not a camera.",
			weight: already ? 0 : 42,
			strength: "strong"
		});
	}
	if (evidence.generativeFill) signals.push({
		id: "gen-fill",
		title: "Generative edit",
		detail: "The file mentions generative fill or expand. At least part of this picture was synthesized.",
		weight: 34,
		strength: "strong"
	});
	if (evidence.c2pa === "trained") signals.push({
		id: "c2pa-trained",
		title: "Content Credentials: trained model",
		detail: "A C2PA manifest says this media came from a trained algorithmic model.",
		weight: 36,
		strength: "strong"
	});
	else if (evidence.c2pa === "capture") signals.push({
		id: "c2pa-capture",
		title: "Content Credentials: camera capture",
		detail: "A C2PA manifest labels the source as a digital capture rather than a generative model.",
		weight: -18,
		strength: "moderate"
	});
	else if (evidence.c2pa === "present") signals.push({
		id: "c2pa",
		title: "Content Credentials present",
		detail: "A provenance manifest is attached, but it does not clearly say camera or model.",
		weight: 0,
		strength: "hint"
	});
	if (camera) {
		const who = [evidence.cameraMake, evidence.cameraModel].filter(Boolean).join(" ");
		signals.push({
			id: "camera",
			title: spoofRisk ? "Camera tag, texture disagrees" : "Camera make and model",
			detail: spoofRisk ? `${who} is written in the file, but the texture is unusually smooth. Metadata can be copied onto a generated image.` : `${who} is a known camera or phone. Generated files rarely keep a real device tag unless someone forged it.`,
			weight: spoofRisk ? -12 : -30,
			strength: spoofRisk ? "moderate" : "strong"
		});
	} else if (evidence.cameraMake || evidence.cameraModel) signals.push({
		id: "device-unknown",
		title: "Device tag",
		detail: `${[evidence.cameraMake, evidence.cameraModel].filter(Boolean).join(" ")} is present, but it is not a recognized camera maker.`,
		weight: -6,
		strength: "hint"
	});
	if (evidence.exposure && camera && !spoofRisk) signals.push({
		id: "exposure",
		title: "Exposure recorded",
		detail: evidence.exposure,
		weight: -8,
		strength: "moderate"
	});
	if (evidence.lens && camera) signals.push({
		id: "lens",
		title: "Lens recorded",
		detail: evidence.lens,
		weight: -4,
		strength: "hint"
	});
	if (evidence.hasGps && camera && !spoofRisk) signals.push({
		id: "gps",
		title: "Location metadata",
		detail: "A location tag is present. The coordinates are not shown.",
		weight: -4,
		strength: "hint"
	});
	if (evidence.editor && !named) signals.push({
		id: "editor",
		title: `Opened in ${evidence.editor}`,
		detail: "An editor tag means the file was processed. That is not the same as being generated.",
		weight: 3,
		strength: "hint"
	});
	if (evidence.software && !named) {
		const soft = evidence.software.toLowerCase();
		if (!signals.some((s) => s.detail.toLowerCase().includes(soft.slice(0, 18))) && evidence.software.length > 1) signals.push({
			id: "software",
			title: "Software tag",
			detail: evidence.software,
			weight: 0,
			strength: "hint"
		});
	}
	if (evidence.syntheticSize && !camera && !named) signals.push({
		id: "canvas",
		title: "Common generator size",
		detail: "The pixel size matches a canvas that image models use often. Phone photos are usually a different size. This alone is not proof.",
		weight: 6,
		strength: "hint"
	});
	if (evidence.pixel && !evidence.decodeFailed) pushPixel(signals, evidence.pixel, named, camera);
	if (evidence.kind === "video" && evidence.framesSampled) {
		signals.push({
			id: "frames",
			title: "Frames sampled",
			detail: `${evidence.framesSampled} frames were checked. Video generators are not settled by one still.`,
			weight: 0,
			strength: "hint"
		});
		if ((evidence.frameSpread ?? 0) > 18) signals.push({
			id: "spread",
			title: "Frames disagree",
			detail: "Some frames look smoother than others. Mixed or re-encoded clips do this.",
			weight: 4,
			strength: "hint"
		});
	}
	if (evidence.decodeFailed) signals.push({
		id: "decode",
		title: "Preview could not be decoded",
		detail: "The browser could not draw this file. The score uses embedded text and metadata only.",
		weight: 0,
		strength: "hint"
	});
	if (signals.every((s) => s.weight === 0)) signals.unshift({
		id: "none",
		title: "No decisive tag",
		detail: "Nothing in the file names a camera or a generator. Stripped metadata is common for both chat screenshots and downloaded AI images.",
		weight: 0,
		strength: "hint"
	});
	const listed = signals.reduce((sum, signal) => sum + signal.weight, 0);
	let target = BASE + listed;
	if (named) target = Math.max(target, evidence.generativeFill && evidence.generators.length === 0 && !evidence.sdParameters ? 74 : 88);
	if (evidence.c2pa === "trained") target = Math.max(target, 84);
	if (camera && !named && evidence.c2pa !== "trained" && !spoofRisk) target = Math.min(target, 26);
	target = clamp(target);
	const delta = target - (BASE + listed);
	if (delta !== 0) signals.push({
		id: "adjust",
		title: "Score pinned",
		detail: "Marks are kept between 4 and 96, and a clear generator or camera tag is not left in the middle.",
		weight: delta,
		strength: "moderate"
	});
	return {
		score: target,
		verdict: verdictFor(target),
		signals
	};
}
function pushPixel(signals, pixel, named, camera) {
	if (looksSmoothSynthetic(pixel) && !named) signals.push({
		id: "smooth",
		title: "Unusually smooth texture",
		detail: "Flat areas are very clean while a few edges stay sharp. That can be a generator, a beauty filter, or a heavy denoise.",
		weight: camera ? 8 : 8,
		strength: "hint"
	});
	else if (looksNatural(pixel) && !named) signals.push({
		id: "texture",
		title: "Varied fine texture",
		detail: "Grain changes across the frame in a way camera photos often do. Modern generators can imitate this.",
		weight: -6,
		strength: "hint"
	});
	if (pixel.flatSaturation > .55 && pixel.residualStd < .03 && !named) signals.push({
		id: "plastic",
		title: "Flat, saturated color",
		detail: "Large areas are smooth and strongly colored. Illustrations and some generated scenes look like this.",
		weight: 5,
		strength: "hint"
	});
}
function looksSmoothSynthetic(pixel) {
	return pixel.residualStd < .018 && pixel.edgeRatio > .06 && pixel.midRatio < .1;
}
function looksNatural(pixel) {
	return pixel.residualStd > .035 && pixel.blockCv > .4 && pixel.midRatio > .12;
}
function verdictFor(score) {
	if (score >= 67) return "likely_ai";
	if (score <= 34) return "likely_real";
	return "inconclusive";
}
function clamp(n) {
	return Math.max(4, Math.min(96, Math.round(n)));
}
var IMAGE_MAX = 33554432;
var VIDEO_MAX = 125829120;
var IMAGE_SCAN = 12582912;
var VIDEO_HEAD = 4194304;
var VIDEO_TAIL = 2097152;
async function analyzeFile(file, onProgress) {
	const kind = kindOf(file);
	if (kind === "unknown") throw new Error("Use a photo (JPG, PNG, WEBP, GIF) or a video (MP4, WEBM, MOV).");
	const limit = kind === "image" ? IMAGE_MAX : VIDEO_MAX;
	if (file.size > limit) throw new Error(kind === "image" ? "That image is over 32 MB." : "That video is over 120 MB.");
	onProgress?.("Reading the file", .12);
	const { head, tail } = await readEdges(file, kind);
	onProgress?.("Checking tags and metadata", .32);
	const info = inspectFile(head, tail);
	const evidence = evidenceFromContainer(kind, info);
	const previewUrl = URL.createObjectURL(file);
	try {
		if (kind === "image") {
			onProgress?.("Reading texture", .62);
			const decoded = await decodeImage(file, info, evidence);
			onProgress?.("Scoring", .9);
			return finish(file, kind, info, evidence, previewUrl, decoded?.residualUrl, decoded?.width, decoded?.height);
		}
		onProgress?.("Sampling frames", .5);
		const video = await sampleVideo(previewUrl, evidence, onProgress);
		onProgress?.("Scoring", .9);
		return finish(file, kind, info, evidence, previewUrl, video.residualUrl, video.width, video.height, video.duration);
	} catch (error) {
		URL.revokeObjectURL(previewUrl);
		throw error;
	}
}
async function opinionJpegs(file) {
	const kind = kindOf(file);
	if (kind === "image") {
		const bitmap = await createImageBitmap(file);
		try {
			const url = await jpegDataUrl(bitmap, bitmap.width, bitmap.height);
			return url ? [url] : [];
		} finally {
			bitmap.close();
		}
	}
	if (kind !== "video") return [];
	const url = URL.createObjectURL(file);
	const video = document.createElement("video");
	video.muted = true;
	video.playsInline = true;
	video.preload = "auto";
	video.src = url;
	try {
		await waitMedia(video, "loadeddata");
		const duration = Number.isFinite(video.duration) ? video.duration : 0;
		const times = duration > 0 ? [
			.2,
			.5,
			.8
		].map((p) => Math.min(duration * p, Math.max(0, duration - .05))) : [0];
		const out = [];
		for (const time of times) {
			await seekTo(video, time);
			const jpeg = await jpegDataUrl(video, video.videoWidth, video.videoHeight);
			if (jpeg) out.push(jpeg);
		}
		return out;
	} finally {
		video.src = "";
		URL.revokeObjectURL(url);
	}
}
function finish(file, kind, info, evidence, previewUrl, residualUrl, width, height, durationSec) {
	if (width && height) evidence.syntheticSize = isSyntheticCanvas(width, height);
	const judged = judge(evidence);
	return {
		id: crypto.randomUUID(),
		kind,
		fileName: file.name || (kind === "image" ? "image" : "video"),
		mime: file.type || info.format,
		byteLength: file.size,
		width,
		height,
		durationSec,
		verdict: judged.verdict,
		score: judged.score,
		signals: judged.signals,
		facts: buildFacts(file, info, evidence, width, height, durationSec),
		previewUrl,
		residualUrl: residualUrl || void 0,
		framesSampled: evidence.framesSampled
	};
}
async function decodeImage(file, info, evidence) {
	try {
		const bitmap = await createImageBitmap(file);
		try {
			const drawn = drawSource(bitmap, bitmap.width, bitmap.height);
			if (!drawn) {
				evidence.decodeFailed = true;
				return {
					width: bitmap.width || info.width,
					height: bitmap.height || info.height,
					residualUrl: void 0
				};
			}
			evidence.pixel = drawn.stats;
			return {
				width: bitmap.width,
				height: bitmap.height,
				residualUrl: drawn.residualUrl
			};
		} finally {
			bitmap.close();
		}
	} catch {
		evidence.decodeFailed = true;
		return {
			width: info.width,
			height: info.height,
			residualUrl: void 0
		};
	}
}
async function sampleVideo(previewUrl, evidence, onProgress) {
	const video = document.createElement("video");
	video.muted = true;
	video.playsInline = true;
	video.preload = "auto";
	video.src = previewUrl;
	try {
		await waitMedia(video, "loadeddata");
	} catch {
		evidence.decodeFailed = true;
		return {};
	}
	const width = video.videoWidth || void 0;
	const height = video.videoHeight || void 0;
	const duration = Number.isFinite(video.duration) ? video.duration : void 0;
	const fractions = [
		.12,
		.32,
		.5,
		.68,
		.88
	];
	const stats = [];
	let residualUrl;
	for (let i = 0; i < fractions.length; i++) {
		const frac = fractions[i] ?? .5;
		const time = duration ? Math.min(duration * frac, Math.max(0, duration - .05)) : 0;
		try {
			await seekTo(video, time);
		} catch {
			break;
		}
		const drawn = width && height ? drawSource(video, width, height) : void 0;
		if (drawn) {
			stats.push(drawn.stats);
			if (i === 2) residualUrl = drawn.residualUrl;
		}
		onProgress?.(`Sampling frame ${i + 1} of ${fractions.length}`, .5 + i * .08);
	}
	if (!residualUrl && stats.length === 0) {
		const drawn = width && height ? drawSource(video, width, height) : void 0;
		if (drawn) {
			stats.push(drawn.stats);
			residualUrl = drawn.residualUrl;
		}
	}
	if (stats.length === 0) evidence.decodeFailed = true;
	else {
		evidence.pixel = averageStats(stats);
		evidence.framesSampled = stats.length;
		evidence.frameSpread = spread(stats.map((s) => s.residualStd)) * 1e3;
	}
	video.src = "";
	return {
		width,
		height,
		duration,
		residualUrl
	};
}
function averageStats(list) {
	const n = list.length;
	const acc = {
		residualMean: 0,
		residualStd: 0,
		blockCv: 0,
		edgeRatio: 0,
		midRatio: 0,
		flatSaturation: 0
	};
	for (const s of list) {
		acc.residualMean += s.residualMean;
		acc.residualStd += s.residualStd;
		acc.blockCv += s.blockCv;
		acc.edgeRatio += s.edgeRatio;
		acc.midRatio += s.midRatio;
		acc.flatSaturation += s.flatSaturation;
	}
	acc.residualMean /= n;
	acc.residualStd /= n;
	acc.blockCv /= n;
	acc.edgeRatio /= n;
	acc.midRatio /= n;
	acc.flatSaturation /= n;
	return acc;
}
function spread(values) {
	if (values.length < 2) return 0;
	const mean = values.reduce((a, b) => a + b, 0) / values.length;
	const variance = values.reduce((a, b) => a + (b - mean) ** 2, 0) / values.length;
	return Math.sqrt(variance);
}
function buildFacts(file, info, evidence, width, height, durationSec) {
	const facts = [{
		label: "Format",
		value: info.format
	}, {
		label: "Size",
		value: formatBytes(file.size)
	}];
	if (width && height) facts.push({
		label: "Dimensions",
		value: `${width} × ${height}`
	});
	if (durationSec !== void 0) facts.push({
		label: "Duration",
		value: formatDuration(durationSec)
	});
	const camera = [evidence.cameraMake, evidence.cameraModel].filter(Boolean).join(" ");
	if (camera) facts.push({
		label: "Device",
		value: camera
	});
	if (evidence.lens) facts.push({
		label: "Lens",
		value: evidence.lens
	});
	if (evidence.exposure) facts.push({
		label: "Exposure",
		value: evidence.exposure
	});
	if (evidence.taken) facts.push({
		label: "Taken",
		value: evidence.taken
	});
	if (evidence.software) facts.push({
		label: "Software",
		value: evidence.software
	});
	if (evidence.framesSampled) facts.push({
		label: "Frames checked",
		value: String(evidence.framesSampled)
	});
	return facts;
}
async function readEdges(file, kind) {
	if (kind === "image") {
		const head = new Uint8Array(await file.slice(0, Math.min(file.size, IMAGE_SCAN)).arrayBuffer());
		const tailStart = Math.max(0, file.size - 64e3);
		return {
			head,
			tail: file.size > IMAGE_SCAN ? new Uint8Array(await file.slice(tailStart).arrayBuffer()) : /* @__PURE__ */ new Uint8Array()
		};
	}
	return {
		head: new Uint8Array(await file.slice(0, Math.min(file.size, VIDEO_HEAD)).arrayBuffer()),
		tail: file.size > VIDEO_HEAD ? new Uint8Array(await file.slice(Math.max(0, file.size - VIDEO_TAIL)).arrayBuffer()) : /* @__PURE__ */ new Uint8Array()
	};
}
function kindOf(file) {
	const type = file.type.toLowerCase();
	if (type.startsWith("image/")) return "image";
	if (type.startsWith("video/")) return "video";
	const name = file.name.toLowerCase();
	if (/\.(jpe?g|png|webp|gif|bmp|avif)$/.test(name)) return "image";
	if (/\.(mp4|webm|mov|m4v|mkv)$/.test(name)) return "video";
	return "unknown";
}
function waitMedia(el, event) {
	return new Promise((resolve, reject) => {
		const timer = window.setTimeout(() => reject(/* @__PURE__ */ new Error("This video took too long to open.")), 12e3);
		const done = () => {
			window.clearTimeout(timer);
			resolve();
		};
		const fail = () => {
			window.clearTimeout(timer);
			reject(/* @__PURE__ */ new Error("This video could not be played in the browser."));
		};
		el.addEventListener(event, done, { once: true });
		el.addEventListener("error", fail, { once: true });
	});
}
function seekTo(video, time) {
	if (Math.abs(video.currentTime - time) < .08 && video.readyState >= 2) return Promise.resolve();
	return new Promise((resolve, reject) => {
		const timer = window.setTimeout(() => reject(/* @__PURE__ */ new Error("Could not step through this video.")), 8e3);
		const done = () => {
			window.clearTimeout(timer);
			resolve();
		};
		video.addEventListener("seeked", done, { once: true });
		try {
			video.currentTime = time;
		} catch {
			window.clearTimeout(timer);
			reject(/* @__PURE__ */ new Error("Could not step through this video."));
		}
	});
}
function formatBytes(n) {
	if (n < 1024) return `${n} B`;
	if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
	return `${(n / 1048576).toFixed(1)} MB`;
}
function formatDuration(sec) {
	const s = Math.round(sec);
	return `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;
}
var HISTORY_KEY = "trueframe.history.v1";
var COPY = {
	likely_ai: {
		title: "Looks generated",
		lede: "A generator tag, a trained-model credential, or a generation log is in this file."
	},
	likely_real: {
		title: "Looks photographed",
		lede: "A known camera left its make and model, and nothing here names a generator."
	},
	inconclusive: {
		title: "Not enough to call",
		lede: "No decisive camera tag or generator tag. Treat the origin as unknown."
	}
};
function TrueFrameApp({ mode = "web", onSecondOpinion }) {
	const [drag, setDrag] = (0, import_react.useState)(false);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [status, setStatus] = (0, import_react.useState)("Ready");
	const [ratio, setRatio] = (0, import_react.useState)(0);
	const [error, setError] = (0, import_react.useState)("");
	const [report, setReport] = (0, import_react.useState)(null);
	const [history, setHistory] = (0, import_react.useState)([]);
	const [opinion, setOpinion] = (0, import_react.useState)({ state: "idle" });
	const fileRef = (0, import_react.useRef)(null);
	const previewRef = (0, import_react.useRef)(null);
	const inputRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(HISTORY_KEY);
			if (!raw) return;
			const parsed = JSON.parse(raw);
			if (Array.isArray(parsed)) setHistory(parsed.slice(0, 8));
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		return () => {
			if (previewRef.current) URL.revokeObjectURL(previewRef.current);
		};
	}, []);
	async function run(file) {
		setPhase("working");
		setError("");
		setOpinion({ state: "idle" });
		setStatus("Reading the file");
		setRatio(.08);
		fileRef.current = file;
		try {
			const next = await analyzeFile(file, (label, value) => {
				setStatus(label);
				setRatio(value);
			});
			if (previewRef.current && previewRef.current !== next.previewUrl) URL.revokeObjectURL(previewRef.current);
			previewRef.current = next.previewUrl;
			setReport(next);
			setPhase("done");
			setRatio(1);
			setStatus("Done");
			const item = {
				id: next.id,
				fileName: next.fileName,
				kind: next.kind,
				verdict: next.verdict,
				score: next.score,
				at: Date.now()
			};
			setHistory((prev) => {
				const items = [item, ...prev].slice(0, 8);
				try {
					localStorage.setItem(HISTORY_KEY, JSON.stringify(items));
				} catch {}
				return items;
			});
		} catch (err) {
			setPhase("error");
			setStatus("Could not screen that file");
			setError(err instanceof Error ? err.message : "Something went wrong reading that file.");
		}
	}
	async function ask() {
		if (!onSecondOpinion || !report || !fileRef.current) return;
		setOpinion({ state: "loading" });
		try {
			const images = await opinionJpegs(fileRef.current);
			if (!images.length) throw new Error("Could not make a preview to send.");
			const result = await onSecondOpinion(images, report.kind, report.score);
			setOpinion({
				state: "done",
				result
			});
		} catch (err) {
			setOpinion({
				state: "done",
				result: {
					ok: false,
					error: err instanceof Error ? err.message : "The second look failed."
				}
			});
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-paper text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-screen w-full max-w-3xl flex-col px-5 py-8 md:py-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-start justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-ink text-paper",
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Aperture, {
								className: "h-6 w-6",
								strokeWidth: 1.75
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl leading-none font-semibold tracking-tight text-balance",
							children: "TrueFrame"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Photo and video origin check"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "pt-1 text-right text-xs leading-snug text-muted",
						children: ["Developed by", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block font-display text-base leading-none font-semibold text-ink",
							children: "NETHA MANOJ"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-2xl text-sm text-pretty text-muted",
					children: "Drop a still or a clip. TrueFrame reads generator tags, camera metadata, and content credentials on this device. Texture is only a hint. This is a screen, not proof."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-6 flex cursor-pointer flex-col items-center justify-center rounded-3xl border border-dashed px-6 py-10 text-center transition-colors " + (drag ? "border-brass bg-mid-soft" : "border-line bg-card") + (phase === "working" ? " pointer-events-none opacity-80" : ""),
					onDragOver: (e) => {
						e.preventDefault();
						setDrag(true);
					},
					onDragLeave: () => setDrag(false),
					onDrop: (e) => {
						e.preventDefault();
						setDrag(false);
						const file = e.dataTransfer.files?.[0];
						if (file) run(file);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: inputRef,
							type: "file",
							accept: "image/*,video/*,.jpg,.jpeg,.png,.webp,.gif,.mp4,.webm,.mov,.m4v",
							className: "sr-only",
							onChange: (e) => {
								const file = e.target.files?.[0];
								e.target.value = "";
								if (file) run(file);
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex h-12 w-12 items-center justify-center rounded-full bg-paper-deep text-brass",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {
								className: "h-5 w-5",
								strokeWidth: 1.75
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-4 font-display text-2xl font-semibold text-balance",
							children: phase === "working" ? status : "Drop a photo or video"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-2 max-w-sm text-sm text-pretty text-muted",
							children: "JPG, PNG, WEBP, GIF, MP4, WEBM, or MOV. Nothing is uploaded for the on-device screen."
						}),
						phase === "working" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-5 h-1.5 w-full max-w-xs overflow-hidden rounded-full bg-paper-deep",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block h-full bg-brass transition-all",
								style: { width: `${Math.round(ratio * 100)}%` }
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-5 inline-flex min-h-11 items-center rounded-full bg-brass px-5 text-sm font-medium text-paper",
							children: "Choose a file"
						})
					]
				}),
				phase === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 flex items-start gap-2 text-sm text-ai",
					role: "alert",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 h-4 w-4 shrink-0" }), error]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-live": "polite",
					children: report && phase === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportView, {
						report,
						opinion,
						canAsk: Boolean(onSecondOpinion),
						onAsk: () => void ask()
					}) : phase === "idle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-8 grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, {
								n: "01",
								title: "Add a file",
								body: "A camera original, a download, or a clip from your camera roll."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, {
								n: "02",
								title: "Read the file",
								body: "Maker tags, C2PA credentials, and generator logs count more than looks."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hint, {
								n: "03",
								title: "See the call",
								body: "Photographed, generated, or not enough to say. Every point is listed."
							})
						]
					}) : null
				}),
				history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "flex items-center gap-2 text-sm font-medium text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "h-4 w-4" }), "Recent screens"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 divide-y divide-line rounded-2xl border border-line bg-card",
						children: history.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-sm",
									children: item.fileName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted",
									children: item.kind === "video" ? "Video" : "Image"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `shrink-0 rounded-full px-3 py-1 text-xs font-medium ${tone(item.verdict)}`,
								children: [
									COPY[item.verdict].title,
									" · ",
									item.score
								]
							})]
						}, item.id))
					})]
				}) : null,
				mode === "web" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-8 rounded-3xl bg-ink px-5 py-6 text-paper md:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-wide text-paper-deep uppercase",
								children: "Android app"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 font-display text-2xl font-semibold text-balance",
								children: "Install TrueFrame"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-md text-sm text-pretty text-paper-deep",
								children: "Download the APK and open it on your phone. Allow install from this source if Android asks. The app screens files on the phone and does not upload them."
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "/trueframe.apk",
							download: "TrueFrame.apk",
							className: "inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-paper px-5 text-sm font-medium text-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), "Download APK"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs text-paper-deep",
						children: "Developed by NETHA MANOJ"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-sm text-muted",
					children: "On-phone screen. Files stay on this device. Developed by NETHA MANOJ."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "mt-auto border-t border-line pt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl font-semibold",
						children: "Developed by NETHA MANOJ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-sm text-pretty text-muted",
						children: "A clean result can still be wrong. Generators strip tags, editors can forge a camera name, and a real photo can be partly filled by a model. Use this to decide what to inspect next."
					})]
				})
			]
		})
	});
}
function Hint({ n, title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "rounded-2xl border border-line bg-card px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-sm text-brass",
				children: n
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-medium",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-pretty text-muted",
				children: body
			})
		]
	});
}
function ReportView({ report, opinion, canAsk, onAsk }) {
	const copy = COPY[report.verdict];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mt-8 overflow-hidden rounded-3xl border border-line bg-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-0 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-paper-deep p-4",
					children: [report.kind === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						src: report.previewUrl,
						controls: true,
						playsInline: true,
						className: "aspect-square w-full rounded-2xl bg-ink object-contain"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: report.previewUrl,
						alt: "",
						className: "aspect-square w-full rounded-2xl bg-ink object-contain"
					}), report.residualUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: report.residualUrl,
							alt: "",
							className: "h-16 w-16 rounded-xl object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-pretty text-muted",
							children: "Texture map. Brighter marks are fine detail. Smooth generators often look flat here. It is a clue, not a verdict."
						})]
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-5 md:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 text-xs text-muted",
							children: [report.kind === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: report.fileName
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: `mt-3 inline-flex rounded-full px-3 py-1 text-sm font-medium ${tone(report.verdict)}`,
							children: copy.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 font-display text-6xl leading-none font-semibold tabular-nums",
							children: report.score
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "AI likelihood, from a start of 48"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 h-2 overflow-hidden rounded-full bg-paper-deep",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `h-full ${meter(report.verdict)}`,
								style: { width: `${report.score}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-pretty text-muted",
							children: copy.lede
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-line px-5 py-5 md:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						children: "Why this score"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "Positive points lean generated. Negative points lean camera."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-col gap-4",
						children: report.signals.map((signal) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "grid grid-cols-[1fr_auto] gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm font-medium",
								children: [signal.title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-2 text-xs font-normal text-muted",
									children: signal.strength
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-pretty text-muted",
								children: signal.detail
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `pt-0.5 text-sm tabular-nums font-medium ${weightTone(signal.weight)}`,
								children: formatWeight(signal.weight)
							})]
						}, signal.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
				className: "grid grid-cols-2 gap-x-4 gap-y-4 border-t border-line px-5 py-5 sm:grid-cols-3 md:px-6",
				children: report.facts.map((fact) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-xs text-muted",
					children: fact.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "mt-1 text-sm break-words",
					children: fact.value
				})] }, fact.label))
			}),
			canAsk ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-line px-5 py-5 md:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-medium",
						children: "Second look"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-md text-sm text-pretty text-muted",
						children: "Ask Grok to look at a small preview. It can disagree with the file tags. One request, not a proof."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onAsk,
						disabled: opinion.state === "loading",
						className: "inline-flex min-h-11 items-center justify-center rounded-full border border-line bg-paper px-5 text-sm font-medium disabled:opacity-60",
						children: opinion.state === "loading" ? "Looking…" : "Ask Grok"
					})]
				}), opinion.state === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpinionBlock, { opinion: opinion.result }) : null]
			}) : null
		]
	});
}
function OpinionBlock({ opinion }) {
	if (!opinion.ok) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-4 text-sm text-ai",
		children: opinion.error
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 rounded-2xl bg-paper-deep p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-medium",
				children: [COPY[opinion.verdict].title, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-2 tabular-nums text-muted",
					children: opinion.aiLikelihood
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 flex flex-col gap-1",
				children: opinion.notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-pretty text-muted",
					children: note
				}, note))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-muted",
				children: opinion.caveat
			})
		]
	});
}
function tone(verdict) {
	if (verdict === "likely_ai") return "bg-ai-soft text-ai";
	if (verdict === "likely_real") return "bg-real-soft text-real";
	return "bg-mid-soft text-mid";
}
function meter(verdict) {
	if (verdict === "likely_ai") return "bg-ai";
	if (verdict === "likely_real") return "bg-real";
	return "bg-mid";
}
function weightTone(weight) {
	if (weight > 0) return "text-ai";
	if (weight < 0) return "text-real";
	return "text-muted";
}
function formatWeight(weight) {
	if (weight > 0) return `+${weight}`;
	if (weight === 0) return "0";
	return String(weight);
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var MAX_IMAGE = 9e5;
var secondOpinion = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || input.kind !== "image" && input.kind !== "video") throw new Error("Send an image or a video.");
	if (!Array.isArray(input.images) || input.images.length < 1 || input.images.length > 3) throw new Error("Send one to three previews.");
	for (const img of input.images) {
		if (typeof img !== "string" || !img.startsWith("data:image/jpeg;base64,")) throw new Error("Previews must be JPEG.");
		if (img.length > MAX_IMAGE) throw new Error("Preview is too large.");
	}
	return {
		images: input.images,
		kind: input.kind,
		localScore: Number.isFinite(input.localScore) ? input.localScore : 50
	};
}).handler(createSsrRpc("66c831ad5ab9d6a13cdd8441a34681e8f4dc991f495cf92b8e0cca9a13e4a0fa"));
function Home() {
	const ask = useServerFn(secondOpinion);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrueFrameApp, { onSecondOpinion: (images, kind, localScore) => ask({ data: {
		images,
		kind,
		localScore
	} }) });
}
//#endregion
export { Home as component };
